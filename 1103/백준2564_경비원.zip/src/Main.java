import java.io.*;
import java.util.StringTokenizer;

public class Main {
	static int W, H, dongR, dongC, num,result;
	static int[][] points;	//상점, num번째껀 동근

	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		W = Integer.parseInt(st.nextToken());
		H = Integer.parseInt(st.nextToken());
		st = new StringTokenizer(br.readLine());
		num = Integer.parseInt(st.nextToken());
		points = new int[num + 1][3];
		for (int i = 0; i <= num; i++) {
			st = new StringTokenizer(br.readLine());
			int a = Integer.parseInt(st.nextToken());
			int b = Integer.parseInt(st.nextToken());
			if (a == 1) { // 북 0,b
				points[i][1] = b;
			} else if (a == 2) { // 남 H,b
				points[i][0] = H;
				points[i][1] = b;
			} else if (a == 3) { // 서 b,0
				points[i][0] = b;
			} else if (a == 4) { // 북 b,W
				points[i][0] = b;
				points[i][1] = W;
			}
			points[i][2]=a;
		}
		for (int i = 0; i < num; i++) {
			if(points[num][2]+points[i][2]==3) 		//남북
				result+=H+Math.min(points[num][1]+points[i][1],2*W-(points[num][1]+points[i][1]));
			else if(points[num][2]+points[i][2]==7) 	//동서
				result+=W+Math.min(points[num][0]+points[i][0],2*H-(points[num][0]+points[i][0]));
			else 
				result+=Math.abs(points[num][0]-points[i][0])+Math.abs(points[num][1]-points[i][1]);
		}
		System.out.println(result);
	} // end of main
}
