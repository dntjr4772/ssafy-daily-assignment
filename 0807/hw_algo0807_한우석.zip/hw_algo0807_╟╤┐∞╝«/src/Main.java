import java.util.*;

public class Main {

	private static int cnt;
	static int visited[] = new int[100001];
	private static int N, K;

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		N = scan.nextInt();
		K = scan.nextInt();
		Arrays.fill(visited, Integer.MAX_VALUE);
		Queue<Integer> Q = new LinkedList<Integer>();
		Q.add(N);
		visited[N] = 0;
qq:		while (!Q.isEmpty()) {
			int size = Q.size();
			cnt++;
			for (int i = 0; i < size; i++) {
				int cur=Q.poll();
				if (cur == K)
					break qq;
				if (cur * 2 <= 100000 && visited[cur * 2] > cnt) {
					visited[cur * 2] = cnt;
					Q.add(cur*2);
				}
				if (cur + 1 <= 100000 && visited[cur + 1] > cnt) {
					visited[cur + 1] = cnt;
					Q.add(cur+1);
				}
				if (cur - 1 >= 0 && visited[cur - 1] > cnt) {
					visited[cur - 1] = cnt;
					Q.add(cur-1);
				}
			}
		}
		System.out.println(cnt-1);
	}
}
