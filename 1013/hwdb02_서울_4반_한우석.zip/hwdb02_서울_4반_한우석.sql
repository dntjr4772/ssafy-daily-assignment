SELECT * FROM emp;
-- 1
select ename, sal, DNAME
from emp inner join dept
using (deptno);
-- 2
select DNAME
from emp inner join dept
using (deptno)
where ename='king';
-- 3
select *
from dept d left outer join emp e
using (deptno)
union
select *
from emp e left outer join dept d
using (deptno);
-- 4
select concat(e.ENAME,'의 매니저는 ', m.ENAME,'이다')
from emp e inner join emp m
on e.MGR = m.EMPNO;
-- 5
select ENAME,DNAME,SAL,JOB
from emp e inner join dept
using (deptno)
where e.JOB=(
				SELECT JOB
				FROM emp
				where ename="scott"
				);
-- 6
select EMPNO,ENAME,HIREDATE,SAL
from emp e inner join dept
using (deptno)
where e.DEPTNO=(
				SELECT DEPTNO
				FROM emp
				where ename="scott"
				);
-- 7
select EMPNO,ENAME,DNAME,HIREDATE,LOC,SAL
from emp e inner join dept
using (deptno)
where sal>(select avg(sal)
			from emp
			);
-- 8
select EMPNO,ENAME,DNAME,LOC,SAL
from emp inner join dept
using (deptno)
where DEPTNO=30
order by SAL desc;

-- 9
select EMPNO,ENAME,DNAME,LOC, job
from emp inner join dept
using (deptno)
where DEPTNO=10 and job not in (
								select distinct job 
								from emp
								where DEPTNO=30
								);
-- 10
select EMPNO,ENAME,SAL
from emp
where SAL in (
				select SAL
				from emp
				where ENAME='king' or ENAME='james'
				);                                
-- 11
select EMPNO,ENAME,SAL
from emp
where SAL > all (
				select SAL
				from emp
				where DEPTNO=30
				);   
-- 13
select ENAME,SAL
from emp
where year(HIREDATE) in (
				select year(HIREDATE)
				from emp
				where ENAME='ALLEN'
				);                        
                        