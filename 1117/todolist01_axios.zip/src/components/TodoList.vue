<template>
    <div>
        <ul>
            <li v-for="(todoItem) in todoItems" v-bind:key="todoItem.no" class="shadow"
                :class="{done: todoItem.done=='Y'}"
            >
             <i class="checkBtn fas fa-check" v-show="todoItem.done=='N'" @click.stop="completeTodo(todoItem.no)"></i>   
             {{todoItem.content}} : {{todoItem.endDate}}
             <span class="removeBtn" type="button">
                 <i class="far fa-trash-alt" @click="removeTodo(todoItem.no)"></i>
             </span>
            </li>
        </ul>
    </div>
</template>

<script>
    import http from '../http-common';
    export default {
        data() {
            return {
                todoItems: []
            }
        },
        created() {
            this.getTodoList();
        },
        methods: {
            getTodoList(){
                http.get('/todolist/user/java')
                        .then( response =>{  this.todoItems = response.data } )
                        .catch( exp => { console.log('할일 목록 조회에 실패하였습니다. : '+exp)});
            },
            removeTodo(no){
                http.delete('/todolist/todo/'+no)
                      .then(()=>{this.getTodoList();})
                      .catch(exp=>{console.log("할일 삭제 실패"+exp)})
            },
            completeTodo(no){
                http.put('/todolist/todo/done/'+no)
                      .then(()=>{this.getTodoList();})
                      .catch(exp=>{console.log("할일 완료 실패"+exp)})
            }
        }
    }
</script>

<style scoped>
ul {
  list-style-type: none;
  padding-left: 0px;
  margin-top: 0;
  text-align: left;
}
li {
  display: flex;
  min-height: 50px;
  height: 50px;
  line-height: 50px;
  margin: 0.5rem 0;
  padding: 0 0.9rem;
  background: white;
  border-radius: 5px;
}
.checkBtn {
  line-height: 45px;
  color: #62acde;
  margin-right: 5px;
}
.removeBtn {
  margin-left: auto;
  color: #de4343;
}

.list-item {
  display: inline-block;
  margin-right: 10px;
}
.list-move {
  transition: transform 1s;
}
.list-enter-active,
.list-leave-active {
  transition: all 1s;
}
.list-enter,
.list-leave-to {
  opacity: 0;
  transform: translateY(30px);
}
.done{
  background-color: lightslategray;
}
</style>