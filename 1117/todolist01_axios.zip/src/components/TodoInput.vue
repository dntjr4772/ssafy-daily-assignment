<template>
    <div class="inputBox shadow">
        할일입력 : <input type="text" v-model="todo.content" placeholder="할일입력"/>
        기한 : <input type="date" v-model="todo.endDate" placeholder="기한" />
        <span class="addContainer" @click="addTodo">
            <div class="addBtn fas fa-plus" aria-hidden="true"></div>
        </span>
    </div>
</template>

<script>
    import http from '../http-common';

    export default {
        data() {
            return {
                todo:{
                   content: '',
                   endDate: '' 
                }
            }
        },
        methods: {
            addTodo(){
                http.post('/todolist/todo',{
                            content : this.todo.content,
                            endDate : this.todo.endDate,
                            userId : 'java'
                        }).then(()=>{
                            console.log("추가하였습니다.");
                            this.clear();
                        })
                        .catch(()=>{
                            console.log("추가에 실패하였습니다.");
                            this.clear();
                        })
                      ;                      
            },
            clear(){
                this.todo.content = '';
                this.todo.endDate = '';
            } 
        }
    }
</script>

<style scoped>
input:focus {
  outline: none;
}
.inputBox {
  background: white;
  height: 50px;
  line-height: 50px;
  border-radius: 5px;
}
.inputBox input {
  border-style: none;
  font-size: 0.9rem;
}
.addContainer {
  float: right;
  background: linear-gradient(to right, #6478FB, #8763FB);
  display: inline-block;
  width: 3rem;
  border-radius: 0 5px 5px 0;
}
.addBtn {
  color: white;
  vertical-align: middle;
}
</style>