import java.io.*;
import java.util.*;

public class Solution {
	static int[][] map, result;
	static int N;
	static String S;

	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int T = Integer.parseInt(st.nextToken());
		for (int t = 1; t <= T; t++) {
			st = new StringTokenizer(br.readLine());
			N = Integer.parseInt(st.nextToken());
			S = st.nextToken();
			map = new int[N][N];
			result = new int[N][N];

			for (int i = 0; i < N; i++) {
				st = new StringTokenizer(br.readLine());
				for (int j = 0; j < N; j++)
					map[i][j] = Integer.parseInt(st.nextToken());
			}
			switch (S) {
			case "left":
				moveleft();
				break;
			case "right":
				moveright();
				break;
			case "up":
				moveup();
				break;
			case "down":
				movedown();
				break;
			default:
				break;
			}

			bw.write("#" + t + "\n");

			for (int i = 0; i < N; i++) {
				for (int j = 0; j < N; j++)
					bw.write("" + result[i][j] + " ");
				bw.write("\n");
			}
			bw.flush();
		} // end of tc
	}

	static void moveleft() {
		for (int i = 0; i < N; i++) {
			int num1 = 0, num2 = 0, idx = 0;
			for (int j = 0; j < N; j++) {
				if (map[i][j] == 0)
					continue;
				if (num1 == 0)
					num1 = map[i][j];
				else {
					num2 = map[i][j];
					if (num1 == num2) {
						result[i][idx++] = num1 * 2;
						num1 = 0;
						num2 = 0;
					} else {
						result[i][idx++] = num1;
						num1 = num2;
						num2 = 0;
					}
				}
			} // end of for - j
			if (num1 != 0)
				result[i][idx] = num1;
		} // end of for - i
	}
	
	static void moveright() {
		for (int i = 0; i < N; i++) {
			int num1 = 0, num2 = 0, idx = N-1;
			for (int j = N-1; j >= 0; j--) {
				if (map[i][j] == 0)
					continue;
				if (num1 == 0)
					num1 = map[i][j];
				else {
					num2 = map[i][j];
					if (num1 == num2) {
						result[i][idx--] = num1 * 2;
						num1 = 0;
						num2 = 0;
					} else {
						result[i][idx--] = num1;
						num1 = num2;
						num2 = 0;
					}
				}
			} // end of for - j
			if (num1 != 0)
				result[i][idx] = num1;
		} // end of for - i
	}
	
	static void moveup() {
		for (int j = 0; j < N; j++) {
			int num1 = 0, num2 = 0, idx = 0;
			for (int i = 0; i < N; i++) {
				if (map[i][j] == 0)
					continue;
				if (num1 == 0)
					num1 = map[i][j];
				else {
					num2 = map[i][j];
					if (num1 == num2) {
						result[idx++][j] = num1 * 2;
						num1 = 0;
						num2 = 0;
					} else {
						result[idx++][j] = num1;
						num1 = num2;
						num2 = 0;
					}
				}
			} // end of for - j
			if (num1 != 0)
				result[idx][j] = num1;
		} // end of for - i
	}
	
	static void movedown() {
		for (int j = 0; j < N; j++) {
			int num1 = 0, num2 = 0, idx = N-1;
			for (int i = N-1; i >=0; i--) {
				if (map[i][j] == 0)
					continue;
				if (num1 == 0)
					num1 = map[i][j];
				else {
					num2 = map[i][j];
					if (num1 == num2) {
						result[idx--][j] = num1 * 2;
						num1 = 0;
						num2 = 0;
					} else {
						result[idx--][j] = num1;
						num1 = num2;
						num2 = 0;
					}
				}
			} // end of for - j
			if (num1 != 0)
				result[idx][j] = num1;
		} // end of for - i
	}

}
