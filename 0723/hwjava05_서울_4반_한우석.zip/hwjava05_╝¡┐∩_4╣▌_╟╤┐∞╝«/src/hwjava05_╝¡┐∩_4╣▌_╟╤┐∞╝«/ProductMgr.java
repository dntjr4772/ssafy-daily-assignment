package hwjava05_서울_4반_한우석;

public class ProductMgr {
	private Product[] products=new Product[100];
	private static ProductMgr pm;
	private int index=0;
	
	public static ProductMgr getInstance() {
		if(pm == null) {	//객체를 만들기 전이라면
			pm = new ProductMgr();
		}
		return pm;
	}
	
	/**상품을 저장하는 기능*/
	public  void add(Product  p) {
		products[index++]=p;
	}

	/**저장된 상품들을 볼수 있는 기능*/
	public void list() {
		for (int i = 0; i < index; i++) {
			System.out.println(products[i]);
		}
	}

	/**상품 번호로 검색하는 기능*/
	public void list( int num) {
		for (int i = 0; i < index; i++) {
			if(products[i].getNumber()==num)
				System.out.println(products[i]);
		}
	}
	
	/**상품 번호로 삭제하는 기능 */
	public void delete( int num) {
		for (int i = 0; i < index; i++) {
			if(products[i].getNumber()==num) {
				System.out.println(products[i]+"를 삭제하였습니다.");
				System.arraycopy(products, i+1, products, i, index-(i+1));
				index--;
			}	
		}
	}

	/**특정가격 이하의 상품만 검색하는 기능 */
	public void priceList( int price) {
		for (int i = 0; i < index; i++) {
			if(products[i].getPrice()<=price) {
				System.out.println(products[i]);
			}	
		}
	}

}
