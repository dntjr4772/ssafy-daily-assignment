package hwjava04_����_4��_�ѿ켮;

public class ProductTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Tv tv=new Tv(2002,"LED TV",100000,1,42,"LED");
		tv.setPrice(120000);
		System.out.println(tv);
		Refrigerator refrigerator=new Refrigerator(20055,"chefrefriger",1400000,2,300);
		refrigerator.setNum(5);
		System.out.println("refrigerator num : "+refrigerator.getNum());
		System.out.println(refrigerator);
	}

}

class Tv{
	private int number;
	private String name;
	private int price;
	private int num;
	private int inch;
	private String type;
	public Tv(int number, String name, int price, int num, int inch, String type) {
		super();
		this.number = number;
		this.name = name;
		this.price = price;
		this.num = num;
		this.inch = inch;
		this.type = type;
	}
	public Tv() {
		super();
	}
	@Override
	public String toString() {
		return "Tv [number=" + number + ", name=" + name + ", price=" + price + ", num=" + num + ", inch=" + inch
				+ ", type=" + type + "]";
	}
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public int getInch() {
		return inch;
	}
	public void setInch(int inch) {
		this.inch = inch;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	
}

class Refrigerator{
	private int number;
	private String name;
	private int price;
	private int num;
	private int volume;
	
	public Refrigerator(int number, String name, int price, int num, int volume) {
		super();
		this.number = number;
		this.name = name;
		this.price = price;
		this.num = num;
		this.volume = volume;
	}

	public Refrigerator() {
		super();
	}

	@Override
	public String toString() {
		return "Refrigerator [number=" + number + ", name=" + name + ", price=" + price + ", num=" + num + ", volume="
				+ volume + "]";
	}

	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	public int getVolume() {
		return volume;
	}

	public void setVolume(int volume) {
		this.volume = volume;
	}
	
	
	
	
}