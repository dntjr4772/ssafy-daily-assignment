import java.io.*;
import java.util.*;

public class Solution {
	static int N,totalCnt,max,min;
	static int[][] mexi;
	static ArrayList<int[]> cores = new ArrayList<>();
	static int[] dr= {1,0,-1,0};
	static int[] dc= {0,1,0,-1};
	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st;
		int T = Integer.parseInt(br.readLine().trim());
		for (int t = 1; t <= T; t++) {
			N = Integer.parseInt(br.readLine().trim());
			min=Integer.MAX_VALUE;
			max=0;
			mexi = new int[N][N];
			cores.clear();
			for (int i = 0; i < N; i++) {
				st = new StringTokenizer(br.readLine());
				for (int j = 0; j < N; j++) {
					mexi[i][j] = Integer.parseInt(st.nextToken());
					if (mexi[i][j] == 1) {
						if (i == 0 || i == N - 1 || j == 0 || j == N - 1)	//전선이 필요없음
							continue;
						cores.add(new int[] { i, j });
					}
				}
			}
			totalCnt=cores.size();
			go(0,0);
			System.out.println("#"+t+" "+min);
			
		} // end of tc
	} // end of main
	private static void go(int idx,int cCnt) {
		if(idx==totalCnt) {
			int res=getLength();	//놓아진 전선의 길이
			if(max<cCnt) {
				max=cCnt;
				min=res;
			}
			else if(max==cCnt) {	//최대 코어갯수가 같다면 최소길이의 전선으로
				if(min>res) {
					min=res;
				}
			}
			return;
		}
		int[] cur=cores.get(idx);
		int r=cur[0];
		int c=cur[1];
		for (int d = 0; d < 4; d++) {
			if(isAvailable(r,c,d)) {
				setStatus(r,c,d,2);
				go(idx+1,cCnt+1);
				setStatus(r,c,d,0);
			}
		}
		//해당 코어 비선택
		go(idx+1,cCnt);
		
	}
	private static boolean isAvailable(int r, int c, int d) {
		int nr=r,nc=c;
		while(true) {
			nr+=dr[d];
			nc+=dc[d];
			if(nr<0 || nr>=N ||nc<0 || nc>=N) break;	//가장자리
			if(mexi[nr][nc]>=1) return false;	//1: 코어, 2: 전선
		}
		return true;
	}
	
	private static void setStatus(int r, int c, int d,int s) {
		int nr=r,nc=c;
		while(true) {
			nr+=dr[d];
			nc+=dc[d];
			if(nr<0 || nr>=N ||nc<0 || nc>=N) break;	//가장자리
			mexi[nr][nc]=s;
		}
	}
	
	private static int getLength() {
		int cnt=0;
		for (int r = 0; r < N; r++) {
			for (int c = 0; c < N; c++) {
				if(mexi[r][c]==2) cnt++;
			}
		}
		return cnt;
	}
}
