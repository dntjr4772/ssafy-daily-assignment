package com.ssafy.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/login.do")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		
		//1. get parameter
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		
		//2. verify parameter
		if(id == null || id.trim().length()==0 || pw == null || pw.trim().length() == 0) {
			
			request.setAttribute("errorMsg", "아이디와 비밀번호는 필수 입니다.");
			request.getRequestDispatcher("/login.jsp").forward(request, response);
			return;
		}
		
		// 3. call B/L
		UserService userService = new UserService();
		boolean result = userService.login(id, pw);
		
		// 4. move view by B/L result
		if(result) { // 로그인 성공
			
			// session
			HttpSession session = request.getSession(); // 보관함 조회
			session.setAttribute("id", id); // 로그인 상태정보 유지
			
			response.sendRedirect(request.getContextPath()+"/main.jsp");
			return;
			
		}else { // 로그인 실패
			request.setAttribute("errorMsg", "아이디 또는 비밀번호가 일치하지 않습니다.");
			request.getRequestDispatcher("/login.jsp").forward(request, response);
			return;
		}
	
		
	}

}
