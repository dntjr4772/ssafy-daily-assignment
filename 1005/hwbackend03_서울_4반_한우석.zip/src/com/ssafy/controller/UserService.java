package com.ssafy.controller;

// Model : Service Logic
public class UserService {

	
	public boolean login(String id, String pw) {
		if(id.equals("ssafy") && pw.equals("1234")) return true;
		return false;
	}
	
}
