import java.util.*;

public class ProductMgrImpl implements IProductMgr {
	ArrayList<Tv> tvs = new ArrayList<>();
	ArrayList<Refrigerator> refs = new ArrayList<>();
	Iterator iterTv = tvs.iterator();
	Iterator iterRef = refs.iterator();

	@Override
	public void addTv(Tv tv) {
		tvs.add(tv);
	}

	@Override
	public void addRef(Refrigerator ref) {
		refs.add(ref);
	}

	@Override
	public void search() {
		System.out.println("전체 검색");
		for (Refrigerator refrigerator : refs)
			System.out.println(refrigerator);
		for (Tv tv : tvs)
			System.out.println(tv);

	}

	@Override
	public void search(int num) {
		for (Refrigerator refrigerator : refs)
			if (refrigerator.getProductNum() == num)
				System.out.println("상품번호 " + num + " " + refrigerator);
		for (Tv tv : tvs)
			if (tv.getProductNum() == num)
				System.out.println("상품번호 " + num + " " + tv);
	}

	@Override
	public void search(String name) {
		for (Refrigerator refrigerator : refs)
			if (refrigerator.getName().equals(name))
				System.out.println("상품명 " + name + " " + refrigerator);
		for (Tv tv : tvs)
			if (tv.getName().equals(name))
				System.out.println("상품명 " + name + " " + tv);

	}

	@Override
	public void searchTv(String name) {
		for (Tv tv : tvs)
			if (tv.getName().equals(name))
				System.out.println("상품명 " + name + " " + tv);

	}

	@Override
	public void searchRef(String name) {
		for (Refrigerator refrigerator : refs)
			if (refrigerator.getName().equals(name))
				System.out.println("상품명 " + name + " " + refrigerator);

	}

	@Override
	public void searchRef(int volume) {
		for (Refrigerator refrigerator : refs)
			if (refrigerator.getVolume() >= volume)
				System.out.println(volume + "L 이상 냉장고는 " + refrigerator);
	}

	@Override
	public void searchTv(int inch) {
		for (Tv tv : tvs)
			if (tv.getInch() >= inch)
				System.out.println(inch + "inch 이상의 TV는 " + tv);

	}

	@Override
	public void update(int num, int price) {
		for (Refrigerator refrigerator : refs)
			if (refrigerator.getProductNum() == num) {
				refrigerator.setPrice(price);
				System.out.println("상품번호 " + num + " 가격변경 " + price);
			}

		for (Tv tv : tvs)
			if (tv.getProductNum() == num) {
				tv.setPrice(price);
				System.out.println("상품번호 " + num + " 가격변경" + price);
			}
	}

	@Override
	public void delete(int num) {
		for (int i = 0; i < refs.size(); i++) {
			if (refs.get(i).getProductNum() == num) {
				refs.remove(i);
				System.out.println(num+" 삭제 완료");
			}
		}
		for (int i = 0; i < tvs.size(); i++) {
			if(tvs.get(i).getProductNum()==num) {
				tvs.remove(i);
				System.out.println(num+" 삭제 완료");
			}
			
		}
	}

	@Override
	public int totalPrice() {
		int total = 0;
		for (Refrigerator refrigerator : refs)
			total += refrigerator.getPrice();

		for (Tv tv : tvs)
			total += tv.getPrice();
		return total;
	}

}
