package product;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ProductEnrollment
 */
@WebServlet("/ProductEnrollment.do")
public class ProductEnrollment extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public ProductEnrollment() {
        super();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String name = request.getParameter("name");
		String price = request.getParameter("price");
		String description = request.getParameter("description");
		
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		out.println("<html>");
		out.println("	<head>");
		out.println("	<title>SSAFY - 상품 등록 완료</title>");
		out.println("	<body>");
		out.println("	<div align=\"center\">");
		out.println("	<font color=\"steelblue\" size=\"10\">");
		out.println("	상품명:"+name+"<br>");
		out.println("	상품 가격:"+price+"<br>");
		out.println("	상품 설명:"+description+"<br>");
		out.println("	</font>");
		out.println("	</div>");
		out.println("	</body>");
		out.println("</html>");
	}

}
