package com.ssafy.model.service;

import java.util.List;

import com.ssafy.model.dto.Todo;

public interface TodoService {

	// 할일 등록
	boolean insertTodo(Todo todo);
	// 할일 수정
	boolean updateTodo(Todo todo);
	// 할일 삭제
	boolean deleteTodo(int no);
	// 사용자 확인 후 할일 삭제
	boolean deleteTodo(String userId, int no);
	// 특정 사용자의 할일리스트 전체 조회
	List<Todo> selectTodoList(String userId);
	// 할일번호로 할일 조회 
	Todo selectTodo(int no);
	
	// 특정 사용자의 할일리스트 전체 삭제
	int deleteTodoList(String userId);
	// 할일번호로 할일 완료 처리
	boolean updateTodoDone(int no);
	boolean updateTodoDone(String userId, int no);
	
	
	
}
