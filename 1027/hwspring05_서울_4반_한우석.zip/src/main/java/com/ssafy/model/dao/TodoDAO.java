package com.ssafy.model.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import com.ssafy.model.dto.Todo;

@Mapper
@Repository
public interface TodoDAO {

	// 할일 등록
	int insertTodo(Todo todo);
	// 할일 수정
	int updateTodo(Todo todo);
	// 할일 삭제
	int deleteTodo(int no);
	// 특정 사용자의 할일리스트 전체 조회
	List<Todo> selectTodoList(String userId);
	// 할일번호로 할일 조회 
	Todo selectTodo(int no);
	
	// 특정 사용자의 할일리스트 전체 삭제
	int deleteTodoList(String userId);
	// 할일번호로 할일 완료 처리
	int updateTodoDone(int no);
}
