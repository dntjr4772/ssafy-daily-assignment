package com.ssafy.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.model.dao.TodoDAO;
import com.ssafy.model.dto.Todo;

@Service
public class TodoServiceImpl implements TodoService {

	private TodoDAO todoDao;
	
	@Autowired
	public void setTodoDao(TodoDAO todoDao) {
		this.todoDao = todoDao;
	}

	@Override
	public boolean insertTodo(Todo todo) {
		return todoDao.insertTodo(todo) > 0;
	}

	@Override
	public boolean updateTodo(Todo todo) {
		return todoDao.updateTodo(todo) > 0;
	}

	@Override
	public boolean deleteTodo(int no) {
		return todoDao.deleteTodo(no) > 0;
	}
	
	@Override
	public boolean deleteTodo(String userId, int no) {
		if(userId != null && userId.equals(todoDao.selectTodo(no).getUserId())){
			return todoDao.deleteTodo(no) > 0;
		}
		return false;
	}

	@Override
	public List<Todo> selectTodoList(String userId) {
		return todoDao.selectTodoList(userId);
	}

	@Override
	public Todo selectTodo(int no) {
		return todoDao.selectTodo(no);
	}

	@Override
	public int deleteTodoList(String userId) {
		return todoDao.deleteTodoList(userId);
	}

	@Override
	public boolean updateTodoDone(int no) {
		return todoDao.updateTodoDone(no) > 0;
	}
	@Override
	public boolean updateTodoDone(String userId, int no) {
		if(userId != null && userId.equals(todoDao.selectTodo(no).getUserId())){
			return todoDao.updateTodoDone(no) > 0;
		}
		return false;
	}

}
