package com.ssafy.model.dto;

public class Result {
	private boolean isSuccess;
	private Object	data;
	
	public Result(boolean isSuccess, Object data) {
		super();
		this.isSuccess = isSuccess;
		this.data = data;
	}

	public Result(boolean flag) {
		this.isSuccess = flag;
	}

	public boolean isSuccess() {
		return isSuccess;
	}

	public void setSuccess(boolean isSuccess) {
		this.isSuccess = isSuccess;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}
	
}
