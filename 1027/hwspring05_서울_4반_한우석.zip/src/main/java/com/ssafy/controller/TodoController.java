package com.ssafy.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ssafy.model.dto.Todo;
import com.ssafy.model.service.TodoService;

@Controller
public class TodoController {

	private TodoService todoService;
	
	@Autowired
	public void setTodoService(TodoService todoService) {
		this.todoService = todoService;
	}

	@RequestMapping("/")
	public String index(Model model, HttpSession session) {
		String userId = (String)session.getAttribute("userid");
		if(userId != null) {
			return "redirect:/todoList.do";
		}
		return "index";
	}
	
	@RequestMapping("/login.do")
	public String login(@RequestParam String id, HttpSession session) {
		session.setAttribute("userid", id);
		return "redirect:/todoList.do";
	}
	
	@RequestMapping("/logout.do")
	public String logout(HttpSession session) {
		session.invalidate();
		return "redirect:/";
	}
	
	@RequestMapping("/todoList.do")
	public String todoList(Model model, HttpSession session) {
		String userId = (String)session.getAttribute("userid");
		List<Todo> todoList = todoService.selectTodoList(userId);
		model.addAttribute("todoList", todoList);
		return "index";
	}
	
	@RequestMapping("/deleteTodo.do")
	public String delete(@RequestParam int no, HttpSession session) {
		String userId = (String)session.getAttribute("userid");
		todoService.deleteTodo(userId, no);
		return "redirect:/todoList.do";
	}
	
	@RequestMapping("/insertTodo.do")
	public String insert(Todo todo, HttpSession session) {
		String userId = (String)session.getAttribute("userid");
		todo.setUserId(userId);
		todoService.insertTodo(todo);
		return "redirect:/todoList.do";
	}
	
	@RequestMapping("/updateDone.do")
	public String updateDone(int no, HttpSession session) {
		String userId = (String)session.getAttribute("userid");
		todoService.updateTodoDone(userId, no);
		return "redirect:/todoList.do";
	}
	
	@RequestMapping("/deleteAll.do")
	public String deleteAll(HttpSession session) {
		String userId = (String)session.getAttribute("userid");
		todoService.deleteTodoList(userId);
		return "redirect:/todoList.do";
	}
	
}
