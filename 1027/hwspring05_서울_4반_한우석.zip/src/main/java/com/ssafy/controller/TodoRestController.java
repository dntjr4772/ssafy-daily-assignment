package com.ssafy.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.model.dto.Result;
import com.ssafy.model.dto.Todo;
import com.ssafy.model.service.TodoService;

@RestController
@RequestMapping("/rest")
public class TodoRestController {

	private TodoService todoService;
	
	@Autowired
	public void setTodoService(TodoService todoService) {
		this.todoService = todoService;
	}
	
	@GetMapping("/todoList/{userid}")
	public List<Todo> todoList(@PathVariable String userid) {
		return todoService.selectTodoList(userid);
	}
	
	@DeleteMapping("/deleteTodo/{userid}/{no}")
	public Boolean delete(@PathVariable String userid,@PathVariable int no) {
		return todoService.deleteTodo(userid, no);
	}
	
	@PostMapping("/insertTodo")
	public Boolean insert(@RequestBody Todo todo) {
		return todoService.insertTodo(todo);
	}
	
	@PutMapping("/updateDone/{userid}/{no}")
	public Boolean updateDone(@PathVariable String userid,@PathVariable int no) {
		return todoService.updateTodoDone(userid, no);
	}
	
	@DeleteMapping("/deleteTodo/{userid}")
	public int deleteAll(@PathVariable String userid) {
		return todoService.deleteTodoList(userid);
	}
}
