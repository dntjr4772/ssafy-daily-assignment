import java.util.*;

class Main {

	private static int[] dr = { 1, -1, 0, 0 };
	private static int[] dc = { 0, 0, 1, -1 };

	public static void main(String args[]) throws Exception {
		Scanner sc = new Scanner(System.in);
		int N = sc.nextInt();
		String str;
		int[][] map = new int[N][N];
		for (int i = 0; i < N; i++) {
			str = sc.next();
			for (int j = 0; j < N; j++)
				map[i][j] = str.charAt(j);
		}
		// BFS
		Queue<int[]> Q = new LinkedList<int[]>();
		boolean visited[][] = new boolean[N][N];
		for (int i = 0; i < visited.length; i++) {
			Arrays.fill(visited[i], false);
		}
		ArrayList<Integer> houseSize = new ArrayList<Integer>();
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < N; j++) {
				if (!visited[i][j] && map[i][j] == '1') {
					Q.add(new int[] { i, j });
					visited[i][j] = true;
					int size = 1;
					while (!Q.isEmpty()) {
						int r = Q.peek()[0];
						int c = Q.poll()[1];
						for (int k = 0; k < dc.length; k++) {
							int nr = r + dr[k];
							int nc = c + dc[k];
							if (nr < 0 || nr >= N || nc < 0 || nc >= N)
								continue;
							if (map[nr][nc] == '0' || visited[nr][nc])
								continue;
							size++;
							Q.add(new int[] { nr, nc });
							visited[nr][nc]=true;
						}
					} // end of while !Q.empty
					houseSize.add(size);
				}
			}
		}
		Collections.sort(houseSize);
		System.out.println(houseSize.size());
		
		for (Integer size : houseSize) {
			System.out.println(size);
		}

	} // end of main
}