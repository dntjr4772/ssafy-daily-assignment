import java.util.List;

public class EmpTest {

	public static void main(String[] args) {
		EmpMgrImpl mgr=EmpMgrImpl.getInstance();
		mgr.add(new Employee(111,"한우석","대리","it"));
		mgr.add(new Employee(112,"전지현","과장","마케팅"));
		System.out.println("전체 출력");
		printAllEmp(mgr.search());
		System.out.println("empNum : 112 사원");
		System.out.println(mgr.search(112));
		System.out.println("이름으로 검색");
		printAllEmp(mgr.search("우"));
		System.out.println("empNum : 111 사원 부서 이동");
		mgr.update(111, "마케팅");
		printAllEmp(mgr.search());
		System.out.println("empNum : 111 사원 퇴사");
		mgr.delete(111);
		printAllEmp(mgr.search());
		
	}
	public static void printAllEmp(List<Employee> list) {
		for (Employee employee : list) {
			System.out.println(employee);
		}
	}
}
