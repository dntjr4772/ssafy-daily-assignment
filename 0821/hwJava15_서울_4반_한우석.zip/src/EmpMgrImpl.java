import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class EmpMgrImpl implements EmpMgr {
	private static final String DB_NAME = "employee_db";
	private static final String DB_URL = "jdbc:mysql://127.0.0.1:3306/" + DB_NAME
			+ "?serverTimezone=UTC&useUniCode=yes&characterEncoding=UTF-8";
	private static final String DB_USER = "ssafy";
	private static final String DB_PASSWORD = "dntjr";
	private static EmpMgrImpl mgr = null;

	static {
		// 1. Driver Loading
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	static EmpMgrImpl getInstance() {
		if (mgr == null) {
			mgr = new EmpMgrImpl();
		}
		return mgr;
	}

	public Connection getConnection() throws SQLException {
		// 2. Connection
		return DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
	}

	public void close(Connection conn) {
		// 6. close
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void close(Statement stmt) {
		// 6. close
		if (stmt != null) {
			try {
				stmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void close(ResultSet rs) {
		// 6. close
		if (rs != null) {
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	@Override
	public void add(Employee b) {
		Connection conn = null;
		PreparedStatement stmt = null;

		try {
			conn = getConnection();
			String sql = "insert into employee values (?,?,?,?)";
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, b.getEmpNo());
			stmt.setString(2, b.getName());
			stmt.setString(3, b.getPosition());
			stmt.setString(4, b.getDept());
			stmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(stmt);
			close(conn);
		}

	}

	@Override
	public List<Employee> search() {
		List<Employee> list = new ArrayList<>();
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			conn = getConnection();
			String sql = "select * from employee";
			stmt = conn.prepareStatement(sql);
			rs = stmt.executeQuery();
			while (rs.next()) {
				list.add(new Employee(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4)));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return list;
	}

	@Override
	public Employee search(int empNo) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		Employee emp = null;
		try {
			conn = getConnection();
			String sql = "select * from employee where empno= ?";
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, empNo);
			rs = stmt.executeQuery();
			if (rs.next()) {
				emp = new Employee(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return emp;
	}

	@Override
	public List<Employee> search(String name) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		List<Employee> list = new ArrayList<Employee>();
		try {
			conn = getConnection();
			String sql = "Select * from employee where name like ?";
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, '%' + name + '%');
			rs = stmt.executeQuery();
			while (rs.next()) {
				list.add(new Employee(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4)));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return list;
	}

	@Override
	public boolean update(int empNo, String dept) {
		Connection conn = null;
		PreparedStatement stmt = null;
		try {
			conn = getConnection();
			String sql = "update employee set dept=? where empNo=?";
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, dept);
			stmt.setInt(2, empNo);
			stmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		} finally {
			close(stmt);
			close(conn);
		}
		return true;
	}

	@Override
	public boolean delete(int empNo) {

		Connection conn = null;
		PreparedStatement stmt = null;
		try {
			conn = getConnection();
			String sql = "delete from employee where empNo=?";
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, empNo);
			stmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		} finally {
			close(stmt);
			close(conn);
		}
		return true;
	}

}
