package com.java.first;

import java.util.Scanner;

public class Compute {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan=new Scanner(System.in);
		int a,b;
		System.out.println("�� ���� �Է�");
		a=scan.nextInt();
		b=scan.nextInt();
		System.out.println(a*b);
		System.out.println(a/b);
	}

}
