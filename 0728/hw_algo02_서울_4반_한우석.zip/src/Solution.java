import java.util.Scanner;

class Solution{
	public static void main(String args[]) throws Exception{
		Scanner sc = new Scanner(System.in);
		int[] nx= {1,0,-1,0};
		int[] ny= {0,1,0,-1};
		int T=sc.nextInt();
		for(int test_case = 1; test_case <= T; test_case++){
			int N=sc.nextInt();
			int y=0, x=0, dir=0;
			int[][] arr=new int[N][N];
			for (int i = 1; i <= N*N; i++) {
				arr[y][x]=i;
				int dy=y+ny[dir];
				int dx=x+nx[dir];
				if(dy>=N || dx>=N || dy<0 || dx<0 || arr[dy][dx]>0) 
					dir=(dir+1)%4;
				y+=ny[dir];
				x+=nx[dir];
			}
			System.out.println("#"+test_case);
			for (int i = 0; i < N; i++) {
				for (int j = 0; j < N; j++) {
					System.out.print(arr[i][j]+" ");
				}
				System.out.println();
			}
		}	//end of tc
	}		//end of main
}