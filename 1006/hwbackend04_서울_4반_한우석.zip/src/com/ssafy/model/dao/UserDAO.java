package com.ssafy.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.ssafy.model.dto.User;
import com.ssafy.util.DBUtil;

public class UserDAO {

	public boolean selectUser(String id, String pw) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		
		String sql = "select * from ssafy_member where  userid= ?  and  userpwd =?";
		try {
			conn = DBUtil.getConnection();
			// step3. statement 준비
			stmt = conn.prepareStatement(sql);
			// step4-1. binding data
			stmt.setString(1, id);
			stmt.setString(2, pw);
			// step4-2. sql execute
			rs = stmt.executeQuery();
			
			//step5. handling result
			if(rs.next()) {
				return true;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBUtil.close(rs);
			DBUtil.close(stmt);
			DBUtil.close(conn);
		}
		return false;
	}

	public boolean insert(User user) {
		Connection conn = null;
		PreparedStatement stmt = null;
		
		String sql = "insert into ssafy_member(userid,userpwd,username,email,address) values(?,?,?,?,?)";
		try {
			conn = DBUtil.getConnection();
			// step3. statement 준비
			stmt = conn.prepareStatement(sql);
			// step4-1. binding data
			stmt.setString(1, user.getId());
			stmt.setString(2, user.getPwd());
			stmt.setString(3, user.getName());
			stmt.setString(4, user.getEmail());
			stmt.setString(5, user.getAddress());
			// step4-2. sql execute
			return stmt.executeUpdate()>0;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBUtil.close(stmt);
			DBUtil.close(conn);
		}
		return false;
	}

	public User selectUser(String id) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		
		String sql = "select userpwd,username,email,address from ssafy_member where  userid= ?";
		try {
			conn = DBUtil.getConnection();
			// step3. statement 준비
			stmt = conn.prepareStatement(sql);
			// step4-1. binding data
			stmt.setString(1, id);
			// step4-2. sql execute
			rs = stmt.executeQuery();
			
			//step5. handling result
			if(rs.next()) {
				return new User(id, rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4));
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBUtil.close(rs);
			DBUtil.close(stmt);
			DBUtil.close(conn);
		}
		return null;
	}
	
	public boolean update(User user) {
		Connection conn = null;
		PreparedStatement stmt = null;
		
		String sql = "update ssafy_member set userpwd=?,username=?,email=?,address=? where userid=?";
		try {
			conn = DBUtil.getConnection();
			// step3. statement 준비
			stmt = conn.prepareStatement(sql);
			// step4-1. binding data
			stmt.setString(1, user.getPwd());
			stmt.setString(2, user.getName());
			stmt.setString(3, user.getEmail());
			stmt.setString(4, user.getAddress());
			stmt.setString(5, user.getId());
			// step4-2. sql execute
			return stmt.executeUpdate()>0;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBUtil.close(stmt);
			DBUtil.close(conn);
		}
		return false;
	}
}

















