package com.ssafy.model.service;

import com.ssafy.model.dao.UserDAO;
import com.ssafy.model.dto.User;

// Model : Service Logic
public class UserService {

	private UserDAO userDao ;
	
	public UserService() {
		this.userDao = new UserDAO();
	}

	public boolean login(String id, String pw) {
		return userDao.selectUser(id, pw);
	}
	
	public boolean register(User user) {
		//아이디 중복 상황
		if(getUser(user.getId()) != null) throw new RuntimeException("아이디가 중복되었습니다.");
		
		// 아이디가 중복되지 않는 상황
		return userDao.insert(user);
	}
	public User getUser(String id) {
		return userDao.selectUser(id);
	}
	
	public boolean updateUser(User user) {
		return userDao.update(user);
	}
	
}
















