package com.ssafy;

public class Test {
	public static void main(String[] args) {
		for (int i = 1; i <= 9; i++) {
			for (int j = 1; j <= 3; j++) {
				System.out.print(j+" * "+i+" = "+i*j+"	");
			}
			System.out.println("");
		}
		for (int i = 1; i <= 9; i++) {
			for (int j = 4; j <= 6; j++) {
				System.out.print(j+" * "+i+" = "+i*j+"	");
			}
			System.out.println("");
		}
		for (int i = 1; i <= 9; i++) {
			for (int j = 7; j <= 9; j++) {
				System.out.print(j+" * "+i+" = "+i*j+"	");
			}
			System.out.println("");
		}
	}
}
