package com.ssafy.algo;

public class googletest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num=0;	//총 개수
		for (int i = 1000; i <= 8888; i++) {
			if(i%10==8)
				num++;
			if(i%100/10==8)
				num++;
			if(i%1000/100==8)
				num++;
			if(i%10000/1000==8)
				num++;
		}
		System.out.println(num);
	}

}
