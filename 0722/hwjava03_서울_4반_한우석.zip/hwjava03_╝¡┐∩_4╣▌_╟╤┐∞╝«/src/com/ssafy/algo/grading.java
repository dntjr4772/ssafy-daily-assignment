package com.ssafy.algo;

import java.util.Scanner;

public class grading {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		int T = scan.nextInt();
		String[] grades= {"A+","A0","A-","B+","B0","B-","C+","C0","C-","D0"};
		for (int t = 1; t <= T; t++) {
			int N = scan.nextInt();
			int K = scan.nextInt();
			int mid, finals, assignment;
			int[] total = new int[N];
			
			// 총점 계산
			for (int n = 0; n < N; n++) {
				mid = scan.nextInt();
				finals = scan.nextInt();
				assignment = scan.nextInt();
				total[n] = mid * 35 + finals * 45 + assignment * 20;

			}
			int score = total[K-1];
			int number = 0;	//내 앞에 몇명
			// 등수 매기기
			for (int j = 0; j < N; j++) {
				if (score < total[j])
					number++;
			}
			// 학점 매기기
			int num = N/10;	//학점마다 몇명씩?
			
			String output = null;
			
			System.out.printf("#%d %s\n", t, grades[number/num]);
		} // end of testcase
	} // end of main

} // end of class

/*
 * 전부 입력받은것 배열에 넣고 총점을 계산한 다음 총점배열에 추가 정렬x 그냥 반복문 돌리면서 K학생보다 잘한 학생수 ++ 그다음
 * 등수*100/전체학생수
 */