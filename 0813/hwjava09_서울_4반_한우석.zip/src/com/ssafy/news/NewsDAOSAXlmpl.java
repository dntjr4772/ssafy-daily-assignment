package com.ssafy.news;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.SAXException;

public class NewsDAOSAXlmpl implements INewsDAO {
	List<News> list=new ArrayList<>();

	@Override
	public List<News> getNewsList(String url) {
		SAXParserFactory saxParserFactory = SAXParserFactory.newInstance();
		try {
			SAXParser saxParser = saxParserFactory.newSAXParser();
			SAXHandler handler = new SAXHandler();
			saxParser.parse(url, handler);
			//News n = handler.n;
			//list.add(n);
			list=handler.list;

		} catch (ParserConfigurationException | SAXException | IOException e) {
			e.printStackTrace();
		}
		
		return list;
	}
	public News search(int index) {
		return list.get(index);
		
	}
}
