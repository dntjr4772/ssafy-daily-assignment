package com.ssafy.news;

import java.util.ArrayList;
import java.util.List;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class SAXHandler extends DefaultHandler{
	News n=null;
	List<News> list=new ArrayList<>();
	StringBuilder b;
	boolean bTitle = false;
	boolean bDescription = false;
	boolean bLink = false;
	@Override
	public void startElement(String uri, String localName, String qName, Attributes attr) 
		throws SAXException {
		b= new StringBuilder();
		if(qName.equals("title")) {
			bTitle=true;
		}else if(qName.equals("description")){
			bDescription=true;
		}else if(qName.equals("link")){
			bLink=true;
		}
	}
	@Override
	public void characters(char ch[], int start, int length) throws SAXException {
		b.append(new String(ch, start, length));
	}
	
	@Override
	public void endElement(String uri, String localName, String qName) throws SAXException {
		if(bTitle) {
			n= new News();
			n.setTitle(b.toString());
			bTitle=false;
		}else if(bDescription) {
			n.setDesc(b.toString());
			list.add(n);
			bDescription=false;
		}else if(bLink) {
			n.setLink(b.toString());
			bLink=false;
		}
	
	}
}
