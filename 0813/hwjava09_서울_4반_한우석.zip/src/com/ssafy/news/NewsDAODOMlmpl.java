package com.ssafy.news;

import java.io.IOException;
import java.util.*;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.*;
import org.xml.sax.SAXException;

public class NewsDAODOMlmpl implements INewsDAO{
	List<News> list;
	News news;
	@Override
	public List<News> getNewsList(String url) {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder;
		list=new ArrayList<>();
		news=new News();
		try {
			builder = factory.newDocumentBuilder();
			Document doc = builder.parse(url);
			doc.getDocumentElement().normalize();
			//System.out.println(doc);
			Element root = doc.getDocumentElement();
			//System.out.println(root);
			NodeList childNodes = root.getChildNodes();
			//System.out.println(childNodes);
			for(int i = 0; i < childNodes.getLength(); i++){
				Node node = childNodes.item(i);
				System.out.println(node);
				if(node.getNodeType() == Node.ELEMENT_NODE){
					Element element = (Element) node;
					String textContent = element.getTextContent();
					String nodeName = element.getNodeName();
					switch( nodeName ) {
						case "title" 	: 
							System.out.println(555551);
							System.out.println("title : " + textContent); 
							news.setTitle(textContent); 
							break;
						case "description" 	: 
							System.out.println("description : " + textContent); 
							news.setDesc(textContent); 
							break;
						case "link" 	: 
							news.setLink(textContent);
							list.add(news);
							break;
						//default:
							//System.out.println(111111);
					}
				}
			}

		} catch (SAXException | ParserConfigurationException | IOException e1) {
			e1.printStackTrace();
		}
		return list;
	}
}
