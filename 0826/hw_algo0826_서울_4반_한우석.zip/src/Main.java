import java.io.*;
import java.util.*;

public class Main {

	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st;
		int[][] map = new int[20][20];
		int[] dy = { 0, 1, 1, 1 };		//우,우하,하,좌하
		int[] dx = { 1, 1, 0, -1 };
		for (int i = 1; i <= 19; i++) {
			st = new StringTokenizer(br.readLine());
			for (int j = 1; j <= 19; j++) 
				map[i][j] = Integer.parseInt(st.nextToken());
		}
		for (int i = 1; i <= 19; i++) {
			for (int j = 1; j <= 19; j++) {
				if (map[i][j] != 0) {
					for (int k = 0; k < 4; k++) { // 4방향
						int win = map[i][j]; // 현 오목알
						int ny = i, nx = j;
						for (int l = 0; l < 4; l++) { // 4칸 가보기
							ny += dy[k];
							nx += dx[k];
							//값이 벗어났거나 다른 알 혹은 빈곳이면 탈출
							if (!range(ny, nx) || win != map[ny][nx]) {
								win = 0;
								break;
							} 
							
						} // end of l
						if(win!=0) {	//6목 체크
							ny += dy[k];
							nx += dx[k];
							//범위 넘어갔거나 다른 알 혹은 빈곳이면 6목아니므로 승리
							if(!range(ny,nx) || win != map[ny][nx]) {	
								System.out.println(win);
								int a=ny-5*dy[k];
								int b=nx-5*dx[k];
								System.out.printf("%d %d",a,b);
								return;
							}
						}
					}	//end of k
				}
			}
			
		}
		//승부가 결정되지 않음
		System.out.println(0);

	}	//end of main

	private static boolean range(int y, int x) {
		if (x < 1 || x > 19 || y < 1 || y > 19)
			return false;
		else
			return true;
	}
}
