import java.io.*;
import java.util.*;

public class Main2 {
	static int N, d, k, c, result, cnt;
	static int[] arr, pick;
	static Queue<Integer> Q = new LinkedList<>();

	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		N = Integer.parseInt(st.nextToken());
		d = Integer.parseInt(st.nextToken());
		k = Integer.parseInt(st.nextToken());
		c = Integer.parseInt(st.nextToken());
		arr = new int[N];
		pick = new int[d + 1];
		// 배열에 초밥을 다넣고
		for (int n = 0; n < N; n++)
			arr[n] = Integer.parseInt(br.readLine());
		// 0부터 k개를 큐에 넣는다
		for (int i = 0; i < k; i++) {
			Q.add(arr[i]);
			// 새로운 것은 cnt값 +1
			if (++pick[arr[i]] == 1)
				cnt++;
		}
		// 쿠폰 초밥도 미리 넣고 시작
		if (++pick[c] == 1)
			cnt++;
		//결과값 갱신
		result = cnt;
		for (int i = 0; i < N - 1; i++) {
			// 맨 앞 초밥 하나 뺀다.
			int num = Q.poll();
			// 해당 스시가 없을 경우 cnt값 -1
			if (--pick[num] == 0)
				cnt--;
			// 다음 스시를 큐에 넣는다.
			Q.add(arr[(i + k) % N]);
			// 새로운 것은 cnt값 +1
			if (++pick[arr[(i + k) % N]] == 1)
				cnt++;
			//결과값 갱신
			result = Math.max(result, cnt);
		}
		System.out.println(result);
	} // end of main
}
