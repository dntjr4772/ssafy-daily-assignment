import java.io.*;
import java.util.*;

public class Main {
	static int N, d, k, c, result,cnt;
	static int[] arr,pick;

	public static void main(String[] args) throws IOException {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st=new StringTokenizer(br.readLine());
		
		N = Integer.parseInt(st.nextToken());
		d = Integer.parseInt(st.nextToken());
		k = Integer.parseInt(st.nextToken());
		c = Integer.parseInt(st.nextToken());
		arr = new int[N];
		pick=new int[d+1];
		// 배열에 초밥을 다넣고
		for (int n = 0; n < N; n++) 
			arr[n] = Integer.parseInt(br.readLine());
		// 0부터 k개를 먹는다
		for (int i = 0; i < k; i++) {
			//새로운 것은 cnt값 +1
			if(++pick[arr[i]]==1)	
				cnt++;
		}
		//쿠폰용 초밥도 넣고 시작
		if(++pick[c]==1)	
			cnt++;
		result=cnt;
		for (int i = 0; i < N-1; i++) {
			//맨 앞 초밥 하나 뱉는다. 
			//해당 스시가 없을 경우 cnt값 -1
			if(--pick[arr[i]]==0)	
				cnt--;
			//다음 스시를 먹는다.
			//새로운 것은 cnt값 +1
			if(++pick[arr[(i+k)%N]]==1)	
				cnt++;
			result=Math.max(result, cnt);
		}
		System.out.println(result);
	} // end of main
}
