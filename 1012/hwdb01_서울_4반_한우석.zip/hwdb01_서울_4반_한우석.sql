
select *
from emp
where hiredate between '2014-01-01' and '2014-12-31';

select *
from emp
where ename like '%S%';

select *
from emp
where comm is null;

SELECT ENAME, EMPNO, SAL,
SAL*13.5 AS "Salary"
FROM EMP;

SELECT ENAME, SAL, SAL*0.15 as ‘Congratulatoryexpenses’
FROM EMP
WHERE SAL>2000;

