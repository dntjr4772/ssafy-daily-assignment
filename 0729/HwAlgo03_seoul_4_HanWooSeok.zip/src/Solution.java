import java.util.Scanner;

class Solution {
	public static void main(String args[]) throws Exception {
		Scanner sc = new Scanner(System.in);
		int T = sc.nextInt();
		int[] ny = { -1, 1, 0, 0 }; // U D R L
		int[] nx = { 0, 0, 1, -1 }; // 0 1 2 3
		for (int test_case = 1; test_case <= T; test_case++) {
			int H = sc.nextInt();
			int W = sc.nextInt();
			char map[][] = new char[H][W];
			int x = 0, y = 0, d = 0;

			for (int i = 0; i < H; i++) {
				String tmp = sc.next();
				for (int j = 0; j < W; j++) {
					map[i][j] = tmp.charAt(j);
					if (map[i][j] == '<' || map[i][j] == '>' || map[i][j] == 'v' || map[i][j] == '^') {
						if (map[i][j] == '^')
							d = 0;
						else if (map[i][j] == 'v')
							d = 1;
						else if (map[i][j] == '>')
							d = 2;
						else if (map[i][j] == '<')
							d = 3;
						y = i;
						x = j;
					}
				}
			} // 입력 완료
			int N = sc.nextInt();
			String str = sc.next();
			for (int i = 0; i < N; i++) {
				char cur = str.charAt(i);
				int dx, dy;
				if (cur == 'U' || cur == 'D' || cur == 'R' || cur == 'L') {
					if (cur == 'U') {
						d = 0;
						map[y][x] = '^';
					} else if (cur == 'D') {
						d = 1;
						map[y][x] = 'v';
					} else if (cur == 'R') {
						d = 2;
						map[y][x] = '>';
					} else if (cur == 'L') {
						d = 3;
						map[y][x] = '<';
					}

					dx = x + nx[d];
					dy = y + ny[d];

					if (dy >= 0 && dy < H && dx >= 0 && dx < W) {
						if (map[dy][dx] == '.') {
							map[dy][dx] = map[y][x]; // 탱크 이동
							map[y][x] = '.'; // 탱크있던 자리는 평지
							x = dx;
							y = dy; // 탱크 위치 세팅
						}
					}
				} // UDRL
				else if (cur == 'S') {
					// 전차가 현재 바라보고 있는 방향으로 포탄을 발사한다.
					dx = x;
					dy = y;

					while (true) {
						dx += nx[d];
						dy += ny[d];
						if (!(dy >= 0 && dy < H && dx >= 0 && dx < W) || map[dy][dx] == '#')
							break;
						else if (map[dy][dx] == '*') {
							map[dy][dx] = '.';
							break;
						}
					}
				} // end of S
			} // end of N
			System.out.print("#" + test_case + " ");
			for (int i = 0; i < H; i++) {
				for (int j = 0; j < W; j++) {
					System.out.print(map[i][j]);
				}
				System.out.println();
			}

		} // end of tc
	} // end of main
}