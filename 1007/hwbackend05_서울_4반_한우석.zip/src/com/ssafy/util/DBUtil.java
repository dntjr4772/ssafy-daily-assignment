package com.ssafy.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtil {
	static final String URL = "jdbc:mysql://127.0.0.1:3306/ssafyweb?serverTimezone=UTC&useUniCode=yes&characterEncoding=UTF-8";
	static final String DRIVER = "com.mysql.cj.jdbc.Driver";
	static final String ID = "ssafy";
	static final String PASSWORD = "dntjr";

	// static initializer : 클래스 로딩시에 자동으로 딱 한번 수행
	static {
		// step 1. driver class loading and register
		try {
			Class.forName(DRIVER);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

//	private static DataSource ds;
//	
//	static {
//		// naming service에서 커넥션풀 찾아오기
//		try {
//			Context initContext = new InitialContext();
//			
//			Context envContext  = (Context)initContext.lookup("java:/comp/env");
//			ds = (DataSource)envContext.lookup("jdbc/MysqlDB");
//			
//			//ds = (DataSource)initContext.lookup("java:/comp/env/jdbc/MysqlDB");
//		} catch (NamingException e) {
//			e.printStackTrace();
//		}
//	}
	
	public static Connection getConnection() throws SQLException {
		// step 2. dbms와 연결
		return DriverManager.getConnection(URL, ID, PASSWORD);
		// connection pool에서 빌려오기
//		return ds.getConnection();
	}
	
	// Connection, Statement, ResultSet도 모두 AutoCloseable타입
	public static void close(AutoCloseable c) {
		// step 6. resource release 
		if (c != null) {
			try {
				if(c instanceof Connection) {
					System.out.println("close conn : "+c.getClass().getName());
				}
				c.close(); // 커넥션이 풀에서 가져온 커넥션 구현체인경우는 풀로 반납하도록 close가 구현되어서 코드 변경 불필요!!
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}
