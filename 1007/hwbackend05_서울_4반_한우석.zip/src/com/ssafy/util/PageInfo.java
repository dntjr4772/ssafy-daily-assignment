package com.ssafy.util;

public class PageInfo {

	private String url;
	private boolean isForword;
	
	public PageInfo(String url, boolean isForword) {
		super();
		this.url = url;
		this.isForword = isForword;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public boolean isForword() {
		return isForword;
	}

	public void setForword(boolean isForword) {
		this.isForword = isForword;
	}
	
	
	
}
