package com.ssafy.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ssafy.model.dto.User;
import com.ssafy.model.service.UserService;

//@WebServlet("/update.do")
public class UpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		
		//0. parameter encoding
		request.setCharacterEncoding("utf-8"); // post일때만 , get은 서버의 자체설정을 따름
		
		//1. get parameter
		String id = request.getParameter("id");
		String pwd = request.getParameter("pwd");
		String name = request.getParameter("name");
		String email = request.getParameter("email");
		String address = request.getParameter("address");
		User user = new User(id, pwd, name, email, address);
		
		//2. call B/L
		UserService userService = new UserService();
		boolean result = false;
		try {
			result = userService.updateUser(user);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if(result) {
			response.sendRedirect(request.getContextPath()+"/main.jsp");
			return;
		}else {
			response.sendRedirect(request.getContextPath()+"/mypage.do");
			return;
		}
	}

}













