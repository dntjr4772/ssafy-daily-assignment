package com.ssafy.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ssafy.model.dto.User;
import com.ssafy.model.service.UserService;

//@WebServlet("/register.do")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		//0. parameter encoding
		request.setCharacterEncoding("utf-8"); // post일때만 , get은 서버의 자체설정을 따름
		
		//1. get parameter
		String id = request.getParameter("id");
		String pwd = request.getParameter("pwd");
		String name = request.getParameter("name");
		String email = request.getParameter("email");
		String address = request.getParameter("address");
		User user = new User(id, pwd, name, email, address);
		
		//2. call B/L
		UserService userService = new UserService();
		boolean result = false;
		try {
			result = userService.register(user);
			
		} catch (Exception e) {
			request.setAttribute("errorMsg", "회원가입에 실패하였습니다. : "+e.getMessage());
			e.printStackTrace();
		}
		// 3. move page by B/L result
		//회원가입 성공
		if(result) {
			// 자동 로그인 : 로그인컨트롤러로 이동 (이때, 로그인에 필요한 파라미터 유지하며 이동해야하므로 페이지이동은 포워딩!!)
			request.getRequestDispatcher("/login.do").forward(request, response);
			return;
		}else {
			request.getRequestDispatcher("/register.jsp").forward(request, response);
			return;
		}
	}

}














