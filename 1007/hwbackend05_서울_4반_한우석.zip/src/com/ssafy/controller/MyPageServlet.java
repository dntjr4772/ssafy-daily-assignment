package com.ssafy.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ssafy.model.dto.User;
import com.ssafy.model.service.UserService;
//@WebServlet("/mypage.do")
public class MyPageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		
		// 불러올 마이페이지의 회원 id 조회
		HttpSession session = request.getSession();
		String id = (String)session.getAttribute("id");
		
		// call B/L
		UserService userService = new UserService();
		User user = null;
		try {
			user = userService.getUser(id);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		request.setAttribute("user", user);
		request.getRequestDispatcher("/mypage.jsp").forward(request, response);
		return;
	}

}









