package com.ssafy.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ssafy.model.dto.User;
import com.ssafy.model.service.UserService;
import com.ssafy.util.PageInfo;

/**
 * Servlet implementation class MainServlet
 */
@WebServlet("*.do")
public class MainServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserService userService = new UserService();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		process(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		process(request, response);
	}
	
	private void process(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		
		PageInfo page = null;
		try {
			// 공통 전처리
			String uri = request.getServletPath();
			System.out.println(uri);
			if(uri.equals("/login.do")) {
				page = login(request, response);
			}else if(uri.equals("/logout.do")) {
				page = logout(request, response);
			}else if(uri.equals("/mypage.do")) {
				page = myPage(request, response);
			}else if(uri.equals("/register.do")) {
				page = register(request, response);
			}else if(uri.equals("/update.do")) {
				page = update(request, response);
			}else if(uri.equals("/userlist.do")) {
				page = userList(request, response);
			}else if(uri.equals("/search.do")) {
				page = search(request, response);
			}else if(uri.equals("/viewdetails.do")) {
				page = viewDetails(request, response);
			}
		} catch (Exception e) {
			request.setAttribute("error", e.getMessage());
			page = new PageInfo("/error.jsp", true);
		}
		
		// 공통 후처리
		if(page.isForword()) {
			request.getRequestDispatcher(page.getUrl()).forward(request, response);
			return;
		}else {
			response.sendRedirect(request.getContextPath()+page.getUrl());
			return;
		}
		
		
	}
	
	protected PageInfo search(HttpServletRequest request, HttpServletResponse response) 
			throws Exception {
		
		//1. get parameter
		String id = request.getParameter("id");
		// 2. call B/L
		User user = userService.getUser(id);
		List<User> userList = new ArrayList<User>();
		if(user!=null)
			userList.add(user);
		request.setAttribute("userList", userList);
		return new PageInfo("/userlist.jsp", true);
	}

	
	protected PageInfo viewDetails(HttpServletRequest request, HttpServletResponse response) 
			throws Exception {
		
		//1. get parameter
		String id = request.getParameter("id");
		// 2. call B/L
		User user = userService.getUser(id);
		request.setAttribute("user", user);
//		request.getRequestDispatcher("/mypage.jsp").forward(request, response);
		return new PageInfo("/viewdetails.jsp", true);
	}

	protected PageInfo login(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		//1. get parameter
		String id = request.getParameter("id");
		String pw = request.getParameter("pwd");
		
		//2. verify parameter
		if(id == null || id.trim().length()==0 || pw == null || pw.trim().length() == 0) {
			
			request.setAttribute("errorMsg", "아이디와 비밀번호는 필수 입니다.");
			return new PageInfo("/login.jsp", true);
		}
		
		// 3. call B/L
		boolean result = userService.login(id, pw);
		
		// 4. move view by B/L result
		if(result) { // 로그인 성공
			
			// session
			HttpSession session = request.getSession(); // 보관함 조회
			session.setAttribute("id", id); // 로그인 상태정보 유지
			
//			Cookie c = new Cookie("id", id);
//			response.addCookie(c);
			
			return new PageInfo("/main.jsp", false);
			
		}else { // 로그인 실패
			request.setAttribute("errorMsg", "아이디 또는 비밀번호가 일치하지 않습니다.");
			return new PageInfo("/login.jsp", true);
		}
	
		
	}
	
	protected PageInfo logout(HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		
		//  세션 소멸
		request.getSession().invalidate();
		
//		Cookie[] cookies= request.getCookies();
//		if(cookies != null && cookies.length != 0){
//			for(Cookie c : cookies){
//				if(c.getName().equals("id")){
//					c.setMaxAge(0);
//					response.addCookie(c);
//					break;
//				}
//			}
//		}
		
		return new PageInfo("/login.jsp", false);
	}
	
	
	protected PageInfo myPage(HttpServletRequest request, HttpServletResponse response) 
			throws Exception {
		
		// 불러올 마이페이지의 회원 id 조회
		HttpSession session = request.getSession();
		String id = (String)session.getAttribute("id");
		
		// call B/L
		User user = userService.getUser(id);
		
		request.setAttribute("user", user);
//		request.getRequestDispatcher("/mypage.jsp").forward(request, response);
		return new PageInfo("/mypage.jsp", true);
	}
	
	protected PageInfo register(HttpServletRequest request, 
			HttpServletResponse response) throws Exception {

		//1. get parameter
		String id = request.getParameter("id");
		String pwd = request.getParameter("pwd");
		String name = request.getParameter("name");
		String email = request.getParameter("email");
		String address = request.getParameter("address");
		User user = new User(id, pwd, name, email, address);
		
		//2. call B/L
		boolean result = false;
		result = userService.register(user);
		// 3. move page by B/L result
		//회원가입 성공
		if(result) {
			// 자동 로그인 : 로그인컨트롤러로 이동 (이때, 로그인에 필요한 파라미터 유지하며 이동해야하므로 페이지이동은 포워딩!!)
			return new PageInfo("/login.do", true);
		}else {
			request.getRequestDispatcher("/register.jsp").forward(request, response);
			return new PageInfo("/register.jsp", true);
		}
	}	
	
	protected PageInfo update(HttpServletRequest request, HttpServletResponse response) 
			throws Exception {
		//1. get parameter
		String id = request.getParameter("id");
		String pwd = request.getParameter("pwd");
		String name = request.getParameter("name");
		String email = request.getParameter("email");
		String address = request.getParameter("address");
		User user = new User(id, pwd, name, email, address);
		
		//2. call B/L
		boolean result = userService.updateUser(user);
		
		if(result) {
			return new PageInfo("/main.jsp",false);
		}else {
			return new PageInfo("/mypage.do",false);
		}
		
		
	}
	
	protected PageInfo userList(HttpServletRequest request, HttpServletResponse response) 
			throws Exception {
		
		List<User> userList = userService.getUsers();
		
		request.setAttribute("userList", userList);
		return new PageInfo("/userlist.jsp", true);
	}
}













