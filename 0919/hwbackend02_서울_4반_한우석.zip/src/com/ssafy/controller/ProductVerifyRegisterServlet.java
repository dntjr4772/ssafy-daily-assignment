package com.ssafy.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ssafy.model.dto.Product;

@WebServlet("/product/verify/register.do")
public class ProductVerifyRegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, 
			HttpServletResponse response) throws ServletException, IOException {
		
		// parameter 추출 
		request.setCharacterEncoding("utf-8"); // post방식만.
		String name = request.getParameter("name");
		String sPrice = request.getParameter("price");
		String desc = request.getParameter("desc");
		int price = 0;
		
		// parameter 유효성 체크
		ArrayList<String> errorMsg = new ArrayList<String>();
		if(name == null || name.trim().length() == 0) {
			errorMsg.add("상품이름이 입력되지 않았습니다.");
		}
		if(sPrice == null || sPrice.trim().length() == 0) {
			errorMsg.add("상품가격이 입력되지 않았습니다.");
		}else {
			price = Integer.parseInt(sPrice);
		}
		if(desc == null || desc.trim().length() == 0) {
			errorMsg.add("상품설명이 입력되지 않았습니다.");
		}
		
		
		// 유효성 체크 실패 : 다시 입력화면으로 이동시키기
		if(errorMsg.size()>0) {
			// 이동할 화면과 공유할 데이터를 적절한 scope의 보관함에 저장
			request.setAttribute("errorMsg", errorMsg);
			// forwarding /의미 : App root
			RequestDispatcher rd = request.getRequestDispatcher("/product_input.jsp");
			rd.forward(request, response);
			return;
		}else {
			// 유효성 체크 성공 : 결과 화면으로 이동시키기
			// redirect  /의미 : server root
//			response.sendRedirect(request.getContextPath()+"/register_success.jsp");
			
			Product p = new Product(name, price, desc);
			request.setAttribute("product", p);
			request.getRequestDispatcher("/register_success.jsp").forward(request, response);
			
			return;
		}

		
		
		
		
	}

}








