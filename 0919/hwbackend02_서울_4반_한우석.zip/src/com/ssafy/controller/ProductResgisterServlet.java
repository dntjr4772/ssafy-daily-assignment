package com.ssafy.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/product/register.do")
public class ProductResgisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public ProductResgisterServlet() {
        super();
    }

	/*
	 * protected void doGet(HttpServletRequest request, HttpServletResponse
	 * response) throws ServletException, IOException {
	 * 
	 * // parameter 추출 String name = request.getParameter("name"); int price =
	 * Integer.parseInt(request.getParameter("price")); String desc =
	 * request.getParameter("desc");
	 * 
	 * 
	 * // response 내용 출력 // 응답 컨텐츠의 마임타입 지정
	 * response.setContentType("text/html;charset=utf-8"); // 응답헤더에 셋팅되어짐.
	 * PrintWriter out = response.getWriter(); // 응답으로 출력할 내용이 문자일경우
	 * out.println("<html>"); out.println("<body>");
	 * out.println("<h1>입력하신 정보는 다음과 같습니다.</h1>");
	 * out.println("<h3>상품명 : "+name+"</h3>");
	 * out.println("<h3>상품가격 : "+price+"</h3>");
	 * out.println("<h3>상품설명 : "+desc+"</h3>"); out.println("</body>");
	 * out.println("</html>"); out.close();
	 * 
	 * }
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		// parameter 추출 
		request.setCharacterEncoding("utf-8"); // post방식만.
		String name = request.getParameter("name");
		int price = Integer.parseInt(request.getParameter("price"));
		String desc = request.getParameter("desc");
		System.out.println(name);
		
		// 응답 컨텐츠의 마임타입 지정
		response.setContentType("text/html;charset=utf-8"); // 응답헤더에 셋팅되어짐.
		PrintWriter out = response.getWriter(); // 응답으로 출력할 내용이 문자일경우
		out.println("<html>");
		out.println("<body style='background-color:pink'>");
		out.println("<h1>입력하신 정보는 다음과 같습니다.</h1>");
		out.println("<h3>상품명 : "+name+"</h3>");
		out.println("<h3>상품가격 : "+price+"</h3>");
		out.println("<h3>상품설명 : "+desc+"</h3>");
		out.println("</body>");
		out.println("</html>");
		out.close();
		
	}

}










