import java.io.*;
import java.util.StringTokenizer;

public class Main {
	private static int N, result = Integer.MAX_VALUE;
	private static int[][] map;
	static boolean visit[];

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st;
		N = Integer.parseInt(br.readLine());
		map = new int[N][N];
		visit = new boolean[N];
		for (int i = 0; i < N; i++) {
			st = new StringTokenizer(br.readLine());
			for (int j = 0; j < N; j++)
				map[i][j] = Integer.parseInt(st.nextToken());
		}
		DFS(0, 1, 0);
		System.out.println(result);
	} // end of main

	private static void DFS(int cur, int len, int cnt) {
		if (cnt > result)
			return;
		if (len == N) {
			if (map[cur][0] == 0)
				return;
			if (result > cnt + map[cur][0])
				result = cnt + map[cur][0];
			return;
		}
		for (int i = 1; i < N; i++) {
			if (!visit[i] && map[cur][i] != 0) {
				visit[i] = true;
				DFS(i, len + 1, cnt + map[cur][i]);
				visit[i] = false;
			}
		}
	} // end of DFS
}