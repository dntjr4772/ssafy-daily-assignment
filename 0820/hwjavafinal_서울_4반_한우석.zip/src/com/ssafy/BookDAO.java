package com.ssafy;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class BookDAO {
	static {
		// 1. Driver Loading
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	public Connection getConnection() {
		// 2. Connection 
		Connection con = null;
		try {
			con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/corona_db?serverTimezone=UTC&useUniCode=yes&characterEncoding=UTF-8","ssafy","dntjr");
		} catch (SQLException e) {
			System.out.println("커넥션 실패 오류발생");
			e.printStackTrace();
		}
		return con;
	}
	public void close(Connection conn) {
		// 6. close
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			} 
		}
	}
	public void close(Statement stmt) {
		// 6. close
		if (stmt != null) {
			try {
				stmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			} 
		}
	}
	public void close(ResultSet rs) {
		// 6. close
		if (rs != null) {
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			} 
		}
	}
	public void insertBook(Book book) {
		Connection conn = null;
		PreparedStatement stmt = null;
		try {
			conn = getConnection();
			String sql = "insert into book VALUES (?,?,?,?,?,?)";
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, book.getIsbn());
			stmt.setString(2, book.getTitle());
			stmt.setString(3, book.getAuthor());
			stmt.setString(4, book.getPublisher());
			stmt.setInt   (5, book.getPrice());
			stmt.setString(6, book.getDescription());
			stmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(stmt);
			close(conn);
		}
	}
	public void updateBook(Book book) {
		Connection conn = null;
		PreparedStatement stmt = null;
		try {
			conn = getConnection();
			String sql = "update book set title = ?, author = ?, publisher = ?, price = ?, description =? where isbn = ?";
			stmt = conn.prepareStatement(sql);
			
			stmt.setString(1, book.getTitle());
			stmt.setString(2, book.getAuthor());
			stmt.setString(3, book.getPublisher());
			stmt.setInt   (4, book.getPrice());
			stmt.setString(5, book.getDescription());
			stmt.setString(6, book.getIsbn());
			stmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(stmt);
			close(conn);
		}
	}
	public void deleteBook(String isbn) {
		Connection conn = null;
		PreparedStatement stmt = null;
		try {
			conn = getConnection();
			String sql = "delete from book where isbn = ?";
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, isbn);
			stmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(stmt);
			close(conn);
		}
	}
	public Book findBook(String isbn) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		Book book= null;
		try {
			conn = getConnection();
			String sql = "select * from book";
			stmt = conn.prepareStatement(sql);
			rs = stmt.executeQuery();
			while(rs.next()) {
				if(isbn.equals(rs.getString(1))) {
					book=new Book(	rs.getString(1), rs.getString(2), 
							rs.getString(3), rs.getString(4), 
							rs.getInt(5), 	 rs.getString(6));
					break;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(rs);
			close(stmt);
			close(conn);
		}
		return book;
	}
	public List<Book> listBooks() {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		ArrayList<Book> bookList = new ArrayList<Book>();
		try {
			conn = getConnection();
			String sql = "select * from book";
			stmt = conn.prepareStatement(sql);
			rs = stmt.executeQuery();
			while(rs.next()) {
				bookList.add(new Book(	rs.getString(1), rs.getString(2), 
										rs.getString(3), rs.getString(4), 
										rs.getInt(5), 	 rs.getString(6)));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(rs);
			close(stmt);
			close(conn);
		}
		return bookList;
	}
	public int count() {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		int count = 0;
		
		try {
			conn = getConnection();
			String sql = "select count(*) from book";
			stmt = conn.prepareStatement(sql);
			rs = stmt.executeQuery();
			if (rs.next()) {
				count = rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(rs);
			close(stmt);
			close(conn);
		}
		return count;
	}
}



























