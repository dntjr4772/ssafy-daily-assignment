-- 디비생성
CREATE SCHEMA corona_db; 

-- 디비선택
use corona_db; 

CREATE TABLE BOOK (
    isbn char(8),
    title varchar(50) not null,
    author varchar(10) not null,
    publisher varchar(15) not null,
    price int not null,
    description varchar(200),
    PRIMARY KEY (isbn)
);

insert into book VALUES
('a1101','JAVA 기본','자앤 기술연구소','자앤 출판사',23000,'기본');

insert into book VALUES
('a1102','JAVA 중급','자앤 기술연구소','자앤 출판사',25000,'중급');

insert into book VALUES
('a1103','JAVA 실전','자앤 기술연구소','자앤 출판사',30000,'실전');

select *
from book;

select *
from book
where isbn = 'a1101';

insert into book VALUES
('a1104','JAVA 심화','자앤 기술연구소','자앤 출판사',28000,'심화');

UPDATE book
   SET price = 20000
 WHERE isbn = 'a1101'; 

DELETE FROM book
 WHERE isbn = 'a1103';
