import java.io.*;
import java.util.StringTokenizer;

public class Main {
	static int result = Integer.MAX_VALUE, N;
	private static int[][] arr;
	private static boolean[] visit;

	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		N = Integer.parseInt(st.nextToken());
		arr = new int[N][N];
		visit = new boolean[N];
		for (int i = 0; i < N; i++) {
			st = new StringTokenizer(br.readLine());
			for (int j = 0; j < N; j++)
				arr[i][j] = Integer.parseInt(st.nextToken());
		}
		comb(0, 0);
		System.out.println(result);
	}

	private static void comb(int start, int depth) {
		if (depth == N / 2) {
			teamAbility();
			return;
		}
		for (int i = start; i < N; i++) {
			visit[i] = true;
			comb(i + 1, depth + 1);
			visit[i] = false;
		}

	}

	private static void teamAbility() {
		int sTeam = 0, lTeam = 0;
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < N; j++) {
				if (visit[i] && visit[j]) {
					sTeam += arr[i][j];
				} else if (!visit[i] && !visit[j]) {
					lTeam += arr[i][j];
				}
			}
		}
		if (result > Math.abs(sTeam - lTeam))
			result = Math.abs(sTeam - lTeam);
	}

}
