
public interface IProductMgr {
	void addTv(Tv tv);
	void addRef(Refrigerator ref);
	void search();
	void search(int num);
	void search(String name);
	void searchTv(String name);
	void searchRef(String name);
	void searchRef(int volume);
	void searchTv(int inch);
	void update(int num,int price);
	void delete(int num);
	int totalPrice();
	void fileWrite();
	void sendProduct();
}
