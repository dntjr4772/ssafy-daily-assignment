
public class Tv extends Product {
	int inch;

	public Tv() {
	}

	public Tv(int inch, String name, int productNum, int price) {
		super(name, productNum, price);
		this.inch = inch;
	}

	public int getInch() {
		return inch;
	}

	public void setInch(int inch) {
		this.inch = inch;
	}

	@Override
	public String toString() {
		return "Tv [inch=" + inch + ", name=" + super.name + ", productNum=" + super.productNum + ", price="
				+ super.price + "]\n";
	}

}
