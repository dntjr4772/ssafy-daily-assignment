
public class ProductTest {
	public static void main(String[] args) {
		IProductMgr mgr=new ProductMgrImpl();
		mgr.addTv(new Tv(60,"QLED TV",123,150000));
		mgr.addTv(new Tv(42,"LED TV",111,50000));
		mgr.addRef(new Refrigerator(500,"Dream 냉장고",1000,600000));
		mgr.addRef(new Refrigerator(300,"싱싱 냉장고",8000,400000));
		mgr.search();
		mgr.search(111);
		mgr.searchRef("싱싱 냉장고");
		mgr.searchRef(400);
		mgr.searchTv(50);
		mgr.update(123, 120000);
		mgr.delete(1000);
		mgr.search();
		mgr.fileWrite();
		System.out.println("전체 가격은 "+ mgr.totalPrice());
		mgr.sendProduct();
	}

}
