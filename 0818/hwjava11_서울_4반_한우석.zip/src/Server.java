import java.io.*;
import java.net.*;

public class Server {
	private static int port = 5100;

	public static void main(String[] args) {
		try (ServerSocket serverSocket = new ServerSocket(port)) {

			System.out.println("NetworkServer Started");

			while (true) {
				Socket socket = serverSocket.accept();
				InputStream input = socket.getInputStream();
				BufferedReader reader = new BufferedReader(new InputStreamReader(input));
				while (true) {
					String message = reader.readLine();
					if(message.isEmpty())
						break;
					System.out.println(message);
				}
			}

		} catch (IOException e) {
			System.out.println("NetworkSimpleServer exception: " + e.getMessage());
			e.printStackTrace();
		}

		System.out.println("NetworkServer Ended");
	} // end of main

}
