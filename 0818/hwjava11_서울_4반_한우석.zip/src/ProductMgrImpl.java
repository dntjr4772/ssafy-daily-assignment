import java.io.*;
import java.net.Socket;
import java.util.*;


public class ProductMgrImpl implements IProductMgr {
	ArrayList<Product> list=new ArrayList<>();
	ArrayList<Tv> tvs = new ArrayList<>();
	ArrayList<Refrigerator> refs = new ArrayList<>();
	Iterator<Tv> iterTv = tvs.iterator();
	Iterator<Refrigerator> iterRef = refs.iterator();

	public void add(Product product) {
		list.add(product);
	}
	
	@Override
	public void addTv(Tv tv) {
		tvs.add(tv);
	}

	@Override
	public void addRef(Refrigerator ref) {
		refs.add(ref);
	}

	@Override
	public void search() {
		System.out.println("전체 검색");
		for (Refrigerator refrigerator : refs)
			System.out.println(refrigerator);
		for (Tv tv : tvs)
			System.out.println(tv);

	}

	@Override
	public void search(int num) {
		for (Refrigerator refrigerator : refs)
			if (refrigerator.getProductNum() == num)
				System.out.println("상품번호 " + num + " " + refrigerator);
		for (Tv tv : tvs)
			if (tv.getProductNum() == num)
				System.out.println("상품번호 " + num + " " + tv);
	}

	@Override
	public void search(String name) {
		for (Refrigerator refrigerator : refs)
			if (refrigerator.getName().equals(name))
				System.out.println("상품명 " + name + " " + refrigerator);
		for (Tv tv : tvs)
			if (tv.getName().equals(name))
				System.out.println("상품명 " + name + " " + tv);

	}

	@Override
	public void searchTv(String name) {
		for (Tv tv : tvs)
			if (tv.getName().equals(name))
				System.out.println("상품명 " + name + " " + tv);

	}

	@Override
	public void searchRef(String name) {
		for (Refrigerator refrigerator : refs)
			if (refrigerator.getName().equals(name))
				System.out.println("상품명 " + name + " " + refrigerator);

	}

	@Override
	public void searchRef(int volume) {
		for (Refrigerator refrigerator : refs)
			if (refrigerator.getVolume() >= volume)
				System.out.println(volume + "L 이상 냉장고는 " + refrigerator);
	}

	@Override
	public void searchTv(int inch) {
		for (Tv tv : tvs)
			if (tv.getInch() >= inch)
				System.out.println(inch + "inch 이상의 TV는 " + tv);

	}

	@Override
	public void update(int num, int price) {
		for (Refrigerator refrigerator : refs)
			if (refrigerator.getProductNum() == num) {
				refrigerator.setPrice(price);
				System.out.println("상품번호 " + num + " 가격변경 " + price);
			}

		for (Tv tv : tvs)
			if (tv.getProductNum() == num) {
				tv.setPrice(price);
				System.out.println("상품번호 " + num + " 가격변경" + price);
			}
	}

	@Override
	public void delete(int num) {
		for (int i = 0; i < refs.size(); i++) {
			if (refs.get(i).getProductNum() == num) {
				refs.remove(i);
				System.out.println(num+" 삭제 완료");
			}
		}
		for (int i = 0; i < tvs.size(); i++) {
			if(tvs.get(i).getProductNum()==num) {
				tvs.remove(i);
				System.out.println(num+" 삭제 완료");
			}
			
		}
	}

	@Override
	public int totalPrice() {
		int total = 0;
		for (Refrigerator refrigerator : refs)
			total += refrigerator.getPrice();

		for (Tv tv : tvs)
			total += tv.getPrice();
		return total;
	}

	@Override
	public void fileWrite() {
		try(BufferedOutputStream bs = new BufferedOutputStream(new FileOutputStream("product.dat"))) {
			for (Refrigerator refrigerator : refs) 
				bs.write(refrigerator.toString().getBytes());
			
			for (Tv tv : tvs)
				bs.write(tv.toString().getBytes());
		} catch (Exception e) {
	                e.getStackTrace();
			// TODO: handle exception
		}
		
	}

	@Override
	public void sendProduct() {
		String host = "localhost";
		int port = 5100;
		
		try ( Socket socket = new Socket(host, port) ) {
			OutputStream output = socket.getOutputStream();
			PrintWriter writer = new PrintWriter(output, true);
			StringBuilder sb= new StringBuilder();
			for (Refrigerator refrigerator : refs) 
				sb.append(refrigerator.toString());
			for (Tv tv : tvs) 
				sb.append(tv.toString());
				writer.println(sb);
		}catch ( IOException e) {
			 System.out.println("NetworkClient exception: " + e.getMessage());
			 e.printStackTrace();
		 }
		
	}
	
	class Client {
		private String ip;
		private int port;
		private Socket s;
		
		private ObjectOutputStream oos;
		
		public Client(String ip, int port) {
			super();
			this.ip = ip;
			this.port = port;
		}
		
		public void connect( ){
			
			try {
	             s = new Socket(ip, port);

				 oos = new ObjectOutputStream( s.getOutputStream() );

				 new Thread(){
					 public void run(){
						 try{
							 for (Refrigerator refrigerator : refs) 
									oos.writeChars(refrigerator.toString());
						 }catch(IOException e ) {
							 e.printStackTrace();
						 }
					 }				 
				 }.start();
				 
			}catch(Exception e ){
				e.printStackTrace();
			}
		}
	}

}
