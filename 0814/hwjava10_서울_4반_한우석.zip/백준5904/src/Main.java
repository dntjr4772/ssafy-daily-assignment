import java.util.Scanner;

public class Main {

	private static String str;
	private static int N;
	private static char result;
	
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		N=scan.nextInt();
		str=new String();
		str.concat("moo");
		
		recur(1);
		System.out.println(result);
	}

	private static void recur(int k) {
		if(str.length()>=N || k==3) {
			result=str.charAt(N-1);
			return;
		}
		String tmp=new String(str);	//이전 수열
		str.concat(tmp).concat("m");
		for (int i = 0; i <k+2 ; i++) {
			str.concat("o");
		}
		str.concat(tmp);
		System.out.println(str);
		recur(k+1);
	}
	
}
