import java.io.*;
import java.util.*;

public class Main {

	private static boolean[][] arr;
	private static boolean[] visited;
	private static int N;
	static Queue<Integer> Q = new LinkedList<>();
	private static int cnt;

	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		N = Integer.parseInt(st.nextToken());
		int a, b;
		arr = new boolean[N + 1][N + 1];
		visited = new boolean[N + 1];
		st = new StringTokenizer(br.readLine());
		int num = Integer.parseInt(st.nextToken());
		for (int i = 0; i < num; i++) {
			st = new StringTokenizer(br.readLine());
			a = Integer.parseInt(st.nextToken());
			b = Integer.parseInt(st.nextToken());
			arr[a][b] = true;
			arr[b][a] = true;
		}
		visited[1] = true;
		Q.add(1);
		while (!Q.isEmpty()) {
			int cur = Q.poll();
			for (int i = 1; i <= N; i++) {
				if (arr[cur][i] && !visited[i]) {
					Q.add(i);
					visited[i] = true;
					cnt++;
				}
			}
		}
		System.out.println(cnt);
	} // end of main

}
