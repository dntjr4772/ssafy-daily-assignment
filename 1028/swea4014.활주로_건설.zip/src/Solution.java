import java.io.*;
import java.util.*;

public class Solution {

	private static int N, X, cnt;

	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int T = Integer.parseInt(st.nextToken());
		for (int t = 1; t <= T; t++) {
			cnt = 0;
			boolean[] col, row;
			st = new StringTokenizer(br.readLine());
			N = Integer.parseInt(st.nextToken());
			X = Integer.parseInt(st.nextToken());
			int[][] arr = new int[N][N];
			int[][] arr2 = new int[N][N];
			col = new boolean[N];
			row = new boolean[N];
			for (int i = 0; i < N; i++) {
				st = new StringTokenizer(br.readLine());
				for (int j = 0; j < N; j++) {
					arr[i][j] = Integer.parseInt(st.nextToken());
					arr2[j][i]=arr[i][j];
				}
			}
			// 일단 가로 세로 똑같은 숫자만 있는거 카운트
			for (int i = 0; i < N; i++) {
				int num = arr[i][0];
				boolean check = true;
				for (int j = 1; j < N; j++) {
					if (num != arr[i][j]) {
						check = false;
						break;
					}
				}
				if (check) {
					cnt++;
					col[i] = true;
				}
			}
			for (int i = 0; i < N; i++) {
				int num = arr2[i][0];
				boolean check = true;
				for (int j = 1; j < N; j++) {
					if (num != arr2[i][j]) {
						check = false;
						break;
					}
				}
				if (check) {
					cnt++;
					row[i] = true;
				}
			}
			//가로 경사로 놓고 체크
			for (int i = 0; i < N; i++) {
				if (!col[i]) {
					checking(arr[i]);
				}
			}
			//세로 경사로 놓고 체크
			for (int i = 0; i < N; i++) {
				if (!row[i]) {
					checking(arr2[i]);
				}
			}

			StringBuilder sb = new StringBuilder();
			sb.append("#").append(t).append(" ").append(cnt).append("\n");
			System.out.print(sb);

		} // end of tc
	}

	private static void checking(int[] arr) {
		boolean[] builded = new boolean[N];
		for (int i = 0; i < N - 1; i++) {
			if (arr[i] == arr[i + 1])
				continue;
			else if (arr[i] + 1 == arr[i + 1]) { // 높이가 1낮으면 left검사
				if (!left(arr, i,builded)) {
					return;
				}
			} else if (arr[i] - 1 == arr[i + 1]) { // 높이가 1높으면 right검사
				if(!right(arr, i+1,builded)) {
					return;
				}
			} else
				return;
		}
		cnt++;
	}

	private static boolean right(int[] arr, int s,boolean[] builded) {
		if(s+X>N) 
			return false;
		
		for (int i = s; i < s+X; i++) 
			if(builded[i])
				return false;
		
		for (int i = 0; i < X-1; i++) 
			if(arr[s+i]!=arr[s+i+1])
				return false;
		
		for (int i = 0; i < X; i++) 
			builded[s+i]=true;
		
		return true;
	}

	private static boolean left(int[] arr, int s,boolean[] builded) {
		
		if(s+1-X<0) 
			return false;
		
		for (int i = s; i > s-X; i--) 
			if(builded[i])
				return false;
		
		for (int i = 0; i < X-1; i++) 
			if(arr[s-i]!=arr[s-i-1])
				return false;
		
		for (int i = 0; i < X; i++) 
			builded[s-i]=true;
		
		return true;
	}

}