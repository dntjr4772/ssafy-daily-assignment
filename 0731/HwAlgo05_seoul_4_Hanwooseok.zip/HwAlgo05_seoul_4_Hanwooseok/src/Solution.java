import java.util.Scanner;
import java.util.Stack;

class Solution {
	public static void main(String args[]) throws Exception {
		Scanner scan = new Scanner(System.in);
		for (int test_case = 1; test_case <= 10; test_case++) {
			int len = scan.nextInt();
			String bef = scan.next();
			int star = 0, plus = 0, idx = 0;
			char[] after = new char[len];
			for (int i = 0; i < len; i++) {
				if (isNum(bef.charAt(i)))
					after[idx++] = bef.charAt(i);

				if (star > 0) {
					star--;
					after[idx++] = '*';
				} 
				if (plus > 0 && (i + 1 != len) && (bef.charAt(i + 1) == '+')) {
					plus--;
					after[idx++] = '+';
				}
				if (bef.charAt(i) == '*')
					star++;
				else if (bef.charAt(i) == '+')
					plus++;
			}
			if (plus > 0)
				after[idx] = '+';
			Stack<Integer> operand=new Stack<Integer>();
			int result=0;
			for (int i = 0; i < len; i++) {
				if(isNum(after[i]))
					operand.add(after[i]-'0');
				else {
					int num1=operand.pop();
					int num2=operand.pop();
					if(after[i]=='*')
						result=num1*num2;
					else
						result=num1+num2;
					operand.add(result);
				}
			}
			System.out.printf("#%d %d\n",test_case,operand.pop());
		}
	}

	private static boolean isNum(char c) {
		if ('0' < c && c <= '9')
			return true;
		return false;
	}

}