import java.util.Arrays;

public class ProductTest {
	public static void main(String[] args) {
		ProductMgr mgr=ProductMgr.getInstance();
		mgr.add(new Product("LED TV",100,50000));
		mgr.add(new Product("QLED TV",150,100000));
		mgr.add(new Product("Dream 냉장고",1000,600000));
		mgr.add(new Product("싱싱 냉장고",8000,400000));
		System.out.println(Arrays.toString(mgr.search()));
		System.out.println(mgr.search(150));
		System.out.println(mgr.search("Dream"));
		mgr.delete(1000);
		System.out.println(Arrays.toString(mgr.search()));
		System.out.println(mgr.totalPrice());
	}

}
