
public class Refrigerator extends Product {
	int volume;

	public Refrigerator() {
	}

	public Refrigerator(int volume, String name, int productNum, int price) {
		super(name, productNum, price);
		this.volume = volume;
	}

	public int getVolume() {
		return volume;
	}

	public void setVolume(int volume) {
		this.volume = volume;
	}

	@Override
	public String toString() {
		return "Refrigerator [volume=" + volume + ", name=" + name + ", productNum=" + productNum + ", price=" + price
				+ "]";
	}
	
}
