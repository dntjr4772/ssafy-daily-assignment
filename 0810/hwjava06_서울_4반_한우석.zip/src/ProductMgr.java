import java.util.ArrayList;

public class ProductMgr {
	private static ProductMgr mgr;
	Product[] products = new Product[100];
	Product[] tvs=new Tv[100]; 
	private int index = 0;

	public ProductMgr() {
	}

	public static ProductMgr getInstance() {
		if (mgr == null)
			mgr = new ProductMgr();
		return mgr;
	}

	public void add(Product product) {
		products[index++] = product;
	}

	/** 상품정보 전체를 검색하는 기능 */
	public Product[] search() {
		Product[] newproductcs = new Product[index];
		for (int i = 0; i < index; i++)
			newproductcs[i] = products[i];
		return newproductcs;
	}

	/** 상품번호로 상품을 검색하는 기능 */
	public Product search(int productNum) {
		for (int i = 0; i < index; i++) {
			if (products[i].getProductNum() == productNum)
				return products[i];
		}
		return null;
	}

	/** 상품명으로 상품을 검색하는 기능(상품명 부분 검색 가능) */
	public ArrayList<Product> search(String name) {
		//Product[] newproductcs = new Product[index];
		ArrayList<Product> newproductcs = new ArrayList<Product>();
		int idx = 0;
		for (int i = 0; i < index; i++) {
			if (products[i].getName().contains(name))
				newproductcs.add(products[i]);
		}
		return newproductcs;
	}

	/** TV정보만 검색 */
	public Product[] searchTv(int inch) {
		Product[] newTv = new Tv[index];
		int idx = 0;
		for (int i = 0; i < index; i++) {
			if (((Tv) tvs[i]).getInch()==inch)
				newTv[idx++]=tvs[i];
		}
		return newTv;
	}

	/** Refrigerator만 검색 */
	
	/** 상품번호로 상품을 삭제하는 기능 */
	public boolean delete(int productNum) {
		for (int i = 0; i < index; i++) {
			if (products[i].getProductNum() == productNum) {
				products[i] = null;
				System.arraycopy(products, i + 1, products, i, index - (i + 1));
				index--;
				return true;
			}
		}
		return false;
	}

	/** 전체 재고 상품 금액을 구하는 기능 */
	public int totalPrice() {
		int total=0;
		for (int i = 0; i < index; i++) 
			total+=products[i].getPrice();
		return total;
	}
}
