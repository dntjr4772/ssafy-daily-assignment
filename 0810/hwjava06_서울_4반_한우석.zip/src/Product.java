
public class Product {
	protected String name;
	int productNum;
	int price;
	public Product() {
	}
	public Product(String name, int productNum, int price) {
		super();
		this.name = name;
		this.productNum = productNum;
		this.price = price;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getProductNum() {
		return productNum;
	}
	public void setProductNum(int productNum) {
		this.productNum = productNum;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "Product [name=" + name + ", productNum=" + productNum + ", price=" + price + "]";
	}
	
	
}
