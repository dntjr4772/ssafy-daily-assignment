package hwjava05_서울_4반_한우석;

import java.util.Scanner;

public class ProductTest {

	public static void main(String[] args) {
		ProductMgr pm=ProductMgr.getInstance();
		int num;
		Scanner scan = new Scanner(System.in);
		while(true) {
			System.out.println("<<< Abc 디지털 대리점은 재고 관리 프로그램 >>>\r\n" + 
					"1. 상품 추가\r\n" + 
					"2. 상품 정보 전체 검색\r\n" + 
					"3. 상품번호 검색\r\n" + 
					"4. 상품번호로 삭제\r\n" + 
					"0.   종료\r\n" + 
					"원하는 번호를 선택하세요. _\r\n");
			num=Integer.parseInt(scan.nextLine());
			if(num==0) {
				System.out.println("종료합니다.");
				break;
			}
			switch (num) {
			case 1:
				System.out.println("상품 번호:");
				int number=Integer.parseInt(scan.nextLine());
				System.out.println("상품 이름:");
				String name=scan.nextLine();
				System.out.println("상품 가격:");
				int price=Integer.parseInt(scan.nextLine());
				System.out.println("상품 수량:");
				int quantity=Integer.parseInt(scan.nextLine());
				pm.add(new Product(number,name,price,quantity));
				break;
			case 2:
				pm.list();
				break;
			case 3:
				System.out.println("상품 번호:");
				int productNum=Integer.parseInt(scan.nextLine());
				pm.list(productNum);
				break;
			case 4:
				System.out.println("상품 번호:");
				int delProductNum=Integer.parseInt(scan.nextLine());
				pm.delete(delProductNum);
				break;
			default:
				break;
			}
			
		}
	}

}
