
public class CodeNotFoundException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public CodeNotFoundException() {
		super("상품 번호가 존재하지 않습니다");
	}
	
}
