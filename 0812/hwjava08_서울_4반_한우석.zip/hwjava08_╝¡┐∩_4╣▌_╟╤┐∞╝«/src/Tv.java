
public class Tv extends Product{
	private int inch;
	public Tv() {
		// TODO Auto-generated constructor stub
	}
	public Tv(int num, int price, int stock, String name, int inch) {
		super(num, price, stock, name);
		this.inch = inch;
	}
	public int getInch() {
		return inch;
	}
	public void setInch(int inch) {
		this.inch = inch;
	}
	@Override
	public String toString() {
		return "Tv [inch=" + inch + ", getNum()=" + getNum() + ", getPrice()=" + getPrice() + ", getStock()="
				+ getStock() + ", getName()=" + getName() + "]";
	}
	
}
