import java.util.ArrayList;

public class ProductMgrImpl implements IProductMgr {
	private static ProductMgrImpl mgr;
	ArrayList<Product> list = new ArrayList<>();

	public static ProductMgrImpl getInstance() {
		if (mgr == null)
			mgr = new ProductMgrImpl();
		return mgr;
	}

	@Override
	public void add(Product p) throws DuplicateException {
		for (Product product : list) {
			if (product.getName().equals(p.getName())) {
				throw new DuplicateException();
			}
		}
		System.out.println(p+" 추가");
		list.add(p);
		return;

	}

	@Override
	public void search(int num) throws CodeNotFoundException {
		for (Product product : list) {
			if (product.getNum() == num) {
				System.out.println(product);
				return;
			}
		}
		throw new CodeNotFoundException();
	}

	@Override
	public void searchRef(int volume) throws ProductNotFoundException {
		ArrayList<Product> new_list = new ArrayList<>();
		for (Product product : list) {
			if (product instanceof Refrigerator) {
				if (((Refrigerator) product).getVolume() >= volume)
					new_list.add(product);
			}
		}
		if (new_list.size() > 0) {
			System.out.println(volume + "L 이상의 Refrigerator list");
			for (Product product : new_list) {
				System.out.println(product);
			}
		} else
			throw new ProductNotFoundException();
	}

	@Override
	public void searchTv(int inch) throws ProductNotFoundException {
		ArrayList<Product> new_list = new ArrayList<>();
		for (Product product : list) {
			if (product instanceof Tv) {
				if (((Tv) product).getInch() >= inch)
					new_list.add(product);
			}
		}
		if (new_list.size() > 0) {
			System.out.println(inch + "인 이상의 Tv list");
			for (Product product : new_list) {
				System.out.println(product);
			}
		} else
			throw new ProductNotFoundException();
	}

}
