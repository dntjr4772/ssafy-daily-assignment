/**제품번호, 제품명, 가격 정보, 재고수량*/
public class Product {
	private int num,price,stock;
	private String name;
	public Product() {
	}
	public Product(int num, int price, int stock, String name) {
		super();
		this.num = num;
		this.price = price;
		this.stock = stock;
		this.name = name;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getStock() {
		return stock;
	}
	public void setStock(int stock) {
		this.stock = stock;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "Product [num=" + num + ", price=" + price + ", stock=" + stock + ", name=" + name + "]";
	}
	
	
	
}
