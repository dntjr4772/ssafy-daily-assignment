
public class Refrigerator extends Product{
	private int volume;
	public Refrigerator() {
		// TODO Auto-generated constructor stub
	}
	public Refrigerator(int num, int price, int stock, String name, int volume) {
		super(num, price, stock, name);
		this.volume = volume;
	}
	public int getVolume() {
		return volume;
	}
	public void setVolume(int volume) {
		this.volume = volume;
	}
	@Override
	public String toString() {
		return "Refrigerator [volume=" + volume + ", getNum()=" + getNum() + ", getPrice()=" + getPrice()
				+ ", getStock()=" + getStock() + ", getName()=" + getName() + "]";
	}
	
}
