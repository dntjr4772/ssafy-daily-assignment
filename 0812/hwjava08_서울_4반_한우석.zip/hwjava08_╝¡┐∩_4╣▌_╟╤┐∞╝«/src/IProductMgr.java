
public interface IProductMgr {
	void add(Product p) throws DuplicateException;
	void search(int num) throws CodeNotFoundException;
	void searchRef(int volume) throws ProductNotFoundException;
	void searchTv(int inch) throws ProductNotFoundException;
	
}
