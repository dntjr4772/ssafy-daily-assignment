
public class ProductTest {

	public static void main(String[] args) {
		ProductMgrImpl mgr=ProductMgrImpl.getInstance();
		try {
			mgr.add(new Tv(1111,500000,4,"LED Tv",50));
		} catch (DuplicateException e) {
			System.out.println(e.getMessage());
		}
		try {
			mgr.add(new Tv(2222,400000,7,"RED Tv",36));
		} catch (DuplicateException e) {
			System.out.println(e.getMessage());
		}
		try {
			mgr.add(new Tv(3333,600000,9,"QLED Tv",60));
		} catch (DuplicateException e) {
			System.out.println(e.getMessage());
		}
		try {
			mgr.add(new Tv(3333,600000,9,"QLED Tv",60));
		} catch (DuplicateException e) {
			System.out.println(e.getMessage());
		}
		try {
			mgr.add(new Refrigerator(4444,800000,9,"fresh 냉장고",500));
		} catch (DuplicateException e) {
			System.out.println(e.getMessage());
		}
		try {
			mgr.add(new Refrigerator(4444,800000,9,"normal 냉장고",300));
		} catch (DuplicateException e) {
			System.out.println(e.getMessage());
		}
		
		try {
			mgr.search(3333);
		} catch (CodeNotFoundException e) {
			System.out.println(e.getMessage());
		}
		try {
			mgr.search(6666);
		} catch (CodeNotFoundException e) {
			System.out.println(e.getMessage());
		}
		try {
			mgr.searchTv(50);
		} catch (ProductNotFoundException e) {
			
			System.out.println(e.getMessage());
		}
		try {
			mgr.searchRef(400);
		} catch (ProductNotFoundException e) {
			
			System.out.println(e.getMessage());
		}
	}

}
