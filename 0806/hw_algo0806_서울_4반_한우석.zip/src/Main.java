import java.util.Scanner;

class Main {
	private static int N;
	private static long[][] arr;
	private static long min = Long.MAX_VALUE;

	public static void main(String args[]) throws Exception {
		Scanner sc = new Scanner(System.in);
		N = sc.nextInt();
		arr = new long[N][2];
		for (int i = 0; i < N; i++) {
			arr[i][0] = sc.nextLong();
			arr[i][1] = sc.nextLong();
		}
		recur(0, 1, 0);
		System.out.println(min);
	}

	public static void recur(int idx, long s, long b) {
		if (idx == N) {
			if (min > Math.abs(s - b) && b != 0)
				min = Math.abs(s - b);
			return;
		}
		recur(idx + 1, s * arr[idx][0], b + arr[idx][1]);
		recur(idx + 1, s, b);
	}

}