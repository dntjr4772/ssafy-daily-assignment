import java.io.*;
import java.util.*;

public class Solution {

	private static int[] parents;

	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st;
		StringBuilder sb;
		st = new StringTokenizer(br.readLine());
		int T = Integer.parseInt(st.nextToken());
		int a, b, n, m;
		for (int test_case = 1; test_case <= T; test_case++) {
			sb= new StringBuilder();
			sb.append('#').append(test_case).append(' ');
			st = new StringTokenizer(br.readLine());
			n = Integer.parseInt(st.nextToken());
			m = Integer.parseInt(st.nextToken());
			String result;
			parents = new int[n + 1];
			for (int i = 0; i < n; i++)
				parents[i] = i;
			for (int i = 0; i < m; i++) {
				st = new StringTokenizer(br.readLine());
				if (Integer.parseInt(st.nextToken()) == 0) {
					a = Integer.parseInt(st.nextToken());
					b = Integer.parseInt(st.nextToken());
					union(a, b);
				} else {
					a = Integer.parseInt(st.nextToken());
					b = Integer.parseInt(st.nextToken());
					if (findSet(a) == findSet(b))
						sb.append(1);
					else
						sb.append(0);
				}
			}
			System.out.println(sb);
		} // end of tc
	} // end of main

	private static boolean union(int a, int b) {
		int aRoot = findSet(a);
		int bRoot = findSet(b);
		if (aRoot == bRoot)
			return false;
		parents[bRoot] = aRoot;
		return true;
	}

	private static int findSet(int a) {
		if (parents[a] == a)
			return a;
		else
			return parents[a] = findSet(parents[a]);
	}
}
